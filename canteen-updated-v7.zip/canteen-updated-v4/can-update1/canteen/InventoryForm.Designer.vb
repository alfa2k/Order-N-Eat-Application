﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class InventoryForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Guna2ShadowPanel1 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.CategoryAddToTable = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.ResetItems = New Guna.UI2.WinForms.Guna2Button()
        Me.DeleteItem = New Guna.UI2.WinForms.Guna2Button()
        Me.EditItem = New Guna.UI2.WinForms.Guna2Button()
        Me.AddIetm = New Guna.UI2.WinForms.Guna2Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.comboboxCategory = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtboxQuantity = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtboxItemPrice = New System.Windows.Forms.TextBox()
        Me.txtboxItemName = New System.Windows.Forms.TextBox()
        Me.Guna2ShadowPanel2 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.ItemsDGV = New Guna.UI2.WinForms.Guna2DataGridView()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Guna2ControlBox3 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2ControlBox1 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2ShadowPanel1.SuspendLayout()
        Me.Guna2Panel1.SuspendLayout()
        Me.Guna2ShadowPanel2.SuspendLayout()
        CType(Me.ItemsDGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(47, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(311, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Inventory Management"
        '
        'Guna2ShadowPanel1
        '
        Me.Guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel1.Controls.Add(Me.Guna2Button1)
        Me.Guna2ShadowPanel1.Controls.Add(Me.CategoryAddToTable)
        Me.Guna2ShadowPanel1.Controls.Add(Me.Label6)
        Me.Guna2ShadowPanel1.Controls.Add(Me.Guna2Panel1)
        Me.Guna2ShadowPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Guna2ShadowPanel1.Location = New System.Drawing.Point(47, 81)
        Me.Guna2ShadowPanel1.Name = "Guna2ShadowPanel1"
        Me.Guna2ShadowPanel1.Radius = 20
        Me.Guna2ShadowPanel1.ShadowColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2ShadowPanel1.ShadowDepth = 200
        Me.Guna2ShadowPanel1.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.ForwardDiagonal
        Me.Guna2ShadowPanel1.Size = New System.Drawing.Size(1146, 262)
        Me.Guna2ShadowPanel1.TabIndex = 1
        '
        'Guna2Button1
        '
        Me.Guna2Button1.BorderRadius = 7
        Me.Guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button1.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Guna2Button1.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.Guna2Button1.Location = New System.Drawing.Point(532, 33)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.Size = New System.Drawing.Size(154, 34)
        Me.Guna2Button1.TabIndex = 17
        Me.Guna2Button1.Text = "Add Category"
        '
        'CategoryAddToTable
        '
        Me.CategoryAddToTable.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.CategoryAddToTable.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CategoryAddToTable.Location = New System.Drawing.Point(300, 33)
        Me.CategoryAddToTable.Name = "CategoryAddToTable"
        Me.CategoryAddToTable.PlaceholderText = "New Category"
        Me.CategoryAddToTable.Size = New System.Drawing.Size(187, 34)
        Me.CategoryAddToTable.TabIndex = 16
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label6.ForeColor = System.Drawing.SystemColors.Control
        Me.Label6.Location = New System.Drawing.Point(64, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(181, 25)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Name of Category: "
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.BorderColor = System.Drawing.Color.Transparent
        Me.Guna2Panel1.BorderRadius = 20
        Me.Guna2Panel1.BorderThickness = 1
        Me.Guna2Panel1.Controls.Add(Me.ResetItems)
        Me.Guna2Panel1.Controls.Add(Me.DeleteItem)
        Me.Guna2Panel1.Controls.Add(Me.EditItem)
        Me.Guna2Panel1.Controls.Add(Me.AddIetm)
        Me.Guna2Panel1.Controls.Add(Me.Label5)
        Me.Guna2Panel1.Controls.Add(Me.Label3)
        Me.Guna2Panel1.Controls.Add(Me.comboboxCategory)
        Me.Guna2Panel1.Controls.Add(Me.Label2)
        Me.Guna2Panel1.Controls.Add(Me.txtboxQuantity)
        Me.Guna2Panel1.Controls.Add(Me.Label4)
        Me.Guna2Panel1.Controls.Add(Me.txtboxItemPrice)
        Me.Guna2Panel1.Controls.Add(Me.txtboxItemName)
        Me.Guna2Panel1.Location = New System.Drawing.Point(38, 73)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.Size = New System.Drawing.Size(894, 165)
        Me.Guna2Panel1.TabIndex = 14
        '
        'ResetItems
        '
        Me.ResetItems.BorderRadius = 7
        Me.ResetItems.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.ResetItems.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.ResetItems.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.ResetItems.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.ResetItems.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ResetItems.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ResetItems.ForeColor = System.Drawing.Color.White
        Me.ResetItems.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.ResetItems.Location = New System.Drawing.Point(421, 131)
        Me.ResetItems.Name = "ResetItems"
        Me.ResetItems.Size = New System.Drawing.Size(113, 34)
        Me.ResetItems.TabIndex = 21
        Me.ResetItems.Text = "Reset"
        '
        'DeleteItem
        '
        Me.DeleteItem.BorderRadius = 7
        Me.DeleteItem.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.DeleteItem.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.DeleteItem.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.DeleteItem.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.DeleteItem.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.DeleteItem.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.DeleteItem.ForeColor = System.Drawing.Color.White
        Me.DeleteItem.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.DeleteItem.Location = New System.Drawing.Point(290, 131)
        Me.DeleteItem.Name = "DeleteItem"
        Me.DeleteItem.Size = New System.Drawing.Size(113, 34)
        Me.DeleteItem.TabIndex = 20
        Me.DeleteItem.Text = "Delete"
        '
        'EditItem
        '
        Me.EditItem.BorderRadius = 7
        Me.EditItem.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.EditItem.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.EditItem.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.EditItem.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.EditItem.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.EditItem.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.EditItem.ForeColor = System.Drawing.Color.White
        Me.EditItem.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.EditItem.Location = New System.Drawing.Point(157, 131)
        Me.EditItem.Name = "EditItem"
        Me.EditItem.Size = New System.Drawing.Size(113, 34)
        Me.EditItem.TabIndex = 19
        Me.EditItem.Text = "Edit"
        '
        'AddIetm
        '
        Me.AddIetm.BorderRadius = 7
        Me.AddIetm.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.AddIetm.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.AddIetm.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.AddIetm.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.AddIetm.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.AddIetm.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.AddIetm.ForeColor = System.Drawing.Color.White
        Me.AddIetm.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.AddIetm.Location = New System.Drawing.Point(26, 131)
        Me.AddIetm.Name = "AddIetm"
        Me.AddIetm.Size = New System.Drawing.Size(113, 34)
        Me.AddIetm.TabIndex = 18
        Me.AddIetm.Text = "Add"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.SystemColors.Control
        Me.Label5.Location = New System.Drawing.Point(263, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(146, 25)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Enter Category:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(27, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(187, 25)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Enter Name of Item:"
        '
        'comboboxCategory
        '
        Me.comboboxCategory.AutoRoundedCorners = True
        Me.comboboxCategory.BackColor = System.Drawing.Color.WhiteSmoke
        Me.comboboxCategory.BorderColor = System.Drawing.Color.Transparent
        Me.comboboxCategory.BorderRadius = 17
        Me.comboboxCategory.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.comboboxCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboboxCategory.FillColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.comboboxCategory.FocusedColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.comboboxCategory.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.comboboxCategory.FocusedState.FillColor = System.Drawing.Color.Transparent
        Me.comboboxCategory.FocusedState.ForeColor = System.Drawing.Color.Transparent
        Me.comboboxCategory.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.comboboxCategory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.comboboxCategory.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.comboboxCategory.HoverState.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.comboboxCategory.ItemHeight = 30
        Me.comboboxCategory.ItemsAppearance.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.comboboxCategory.ItemsAppearance.Font = New System.Drawing.Font("Yu Gothic", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.comboboxCategory.ItemsAppearance.ForeColor = System.Drawing.Color.White
        Me.comboboxCategory.Location = New System.Drawing.Point(263, 67)
        Me.comboboxCategory.Name = "comboboxCategory"
        Me.comboboxCategory.Size = New System.Drawing.Size(184, 36)
        Me.comboboxCategory.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material
        Me.comboboxCategory.TabIndex = 12
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(495, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(109, 25)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Enter Price:"
        '
        'txtboxQuantity
        '
        Me.txtboxQuantity.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.txtboxQuantity.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtboxQuantity.Location = New System.Drawing.Point(696, 67)
        Me.txtboxQuantity.Name = "txtboxQuantity"
        Me.txtboxQuantity.PlaceholderText = "Number"
        Me.txtboxQuantity.Size = New System.Drawing.Size(154, 34)
        Me.txtboxQuantity.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(696, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(143, 25)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Enter Quantity:"
        '
        'txtboxItemPrice
        '
        Me.txtboxItemPrice.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.txtboxItemPrice.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtboxItemPrice.Location = New System.Drawing.Point(495, 69)
        Me.txtboxItemPrice.Name = "txtboxItemPrice"
        Me.txtboxItemPrice.PlaceholderText = "Price"
        Me.txtboxItemPrice.Size = New System.Drawing.Size(154, 34)
        Me.txtboxItemPrice.TabIndex = 10
        '
        'txtboxItemName
        '
        Me.txtboxItemName.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.txtboxItemName.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtboxItemName.Location = New System.Drawing.Point(27, 69)
        Me.txtboxItemName.Name = "txtboxItemName"
        Me.txtboxItemName.PlaceholderText = "New Item"
        Me.txtboxItemName.Size = New System.Drawing.Size(187, 34)
        Me.txtboxItemName.TabIndex = 9
        '
        'Guna2ShadowPanel2
        '
        Me.Guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel2.Controls.Add(Me.ItemsDGV)
        Me.Guna2ShadowPanel2.Controls.Add(Me.Label7)
        Me.Guna2ShadowPanel2.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Guna2ShadowPanel2.Location = New System.Drawing.Point(47, 349)
        Me.Guna2ShadowPanel2.Name = "Guna2ShadowPanel2"
        Me.Guna2ShadowPanel2.Radius = 20
        Me.Guna2ShadowPanel2.ShadowColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2ShadowPanel2.ShadowDepth = 200
        Me.Guna2ShadowPanel2.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.ForwardDiagonal
        Me.Guna2ShadowPanel2.Size = New System.Drawing.Size(1146, 312)
        Me.Guna2ShadowPanel2.TabIndex = 2
        '
        'ItemsDGV
        '
        Me.ItemsDGV.AllowUserToResizeColumns = False
        Me.ItemsDGV.AllowUserToResizeRows = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ItemsDGV.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.ItemsDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.ItemsDGV.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ItemsDGV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ItemsDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.ItemsDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Segoe UI", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ItemsDGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.ItemsDGV.ColumnHeadersHeight = 28
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Segoe UI", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ItemsDGV.DefaultCellStyle = DataGridViewCellStyle6
        Me.ItemsDGV.EnableHeadersVisualStyles = False
        Me.ItemsDGV.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ItemsDGV.Location = New System.Drawing.Point(65, 52)
        Me.ItemsDGV.Name = "ItemsDGV"
        Me.ItemsDGV.RowHeadersVisible = False
        Me.ItemsDGV.RowHeadersWidth = 51
        Me.ItemsDGV.RowTemplate.Height = 29
        Me.ItemsDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ItemsDGV.Size = New System.Drawing.Size(1021, 233)
        Me.ItemsDGV.TabIndex = 17
        Me.ItemsDGV.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt
        Me.ItemsDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ItemsDGV.ThemeStyle.AlternatingRowsStyle.Font = Nothing
        Me.ItemsDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty
        Me.ItemsDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty
        Me.ItemsDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty
        Me.ItemsDGV.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ItemsDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(206, Byte), Integer))
        Me.ItemsDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.ItemsDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.ItemsDGV.ThemeStyle.HeaderStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ItemsDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.ItemsDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        Me.ItemsDGV.ThemeStyle.HeaderStyle.Height = 28
        Me.ItemsDGV.ThemeStyle.ReadOnly = False
        Me.ItemsDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.ItemsDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.ItemsDGV.ThemeStyle.RowsStyle.Font = New System.Drawing.Font("Segoe UI", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ItemsDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.ItemsDGV.ThemeStyle.RowsStyle.Height = 29
        Me.ItemsDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(119, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(147, Byte), Integer))
        Me.ItemsDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label7.ForeColor = System.Drawing.SystemColors.Control
        Me.Label7.Location = New System.Drawing.Point(64, 13)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(180, 25)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Inventory Overview"
        '
        'Guna2ControlBox3
        '
        Me.Guna2ControlBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox
        Me.Guna2ControlBox3.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2ControlBox3.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox3.Location = New System.Drawing.Point(1129, 0)
        Me.Guna2ControlBox3.Name = "Guna2ControlBox3"
        Me.Guna2ControlBox3.Size = New System.Drawing.Size(64, 36)
        Me.Guna2ControlBox3.TabIndex = 3
        '
        'Guna2ControlBox1
        '
        Me.Guna2ControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox1.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2ControlBox1.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox1.Location = New System.Drawing.Point(1184, 0)
        Me.Guna2ControlBox1.Name = "Guna2ControlBox1"
        Me.Guna2ControlBox1.Size = New System.Drawing.Size(64, 36)
        Me.Guna2ControlBox1.TabIndex = 4
        '
        'InventoryForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1251, 673)
        Me.Controls.Add(Me.Guna2ControlBox1)
        Me.Controls.Add(Me.Guna2ControlBox3)
        Me.Controls.Add(Me.Guna2ShadowPanel2)
        Me.Controls.Add(Me.Guna2ShadowPanel1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "InventoryForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form3"
        Me.Guna2ShadowPanel1.ResumeLayout(False)
        Me.Guna2ShadowPanel1.PerformLayout()
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.Guna2ShadowPanel2.ResumeLayout(False)
        Me.Guna2ShadowPanel2.PerformLayout()
        CType(Me.ItemsDGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Label1 As Label
    Friend WithEvents Guna2ShadowPanel1 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents comboboxCategory As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents txtboxQuantity As TextBox
    Friend WithEvents txtboxItemPrice As TextBox
    Friend WithEvents txtboxItemName As TextBox
    Friend WithEvents CategoryAddToTable As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2ShadowPanel2 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents DeleteItem As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents EditItem As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents AddIetm As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ItemsDGV As Guna.UI2.WinForms.Guna2DataGridView
    Friend WithEvents Label7 As Label
    Friend WithEvents Guna2ControlBox1 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2ControlBox3 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents ResetItems As Guna.UI2.WinForms.Guna2Button
End Class
