﻿Imports System.Data.SqlClient
Public Class FoodCheckout
    Dim con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v4\can-update1\canteen\Management1.mdf;Integrated Security=True")
    Private Sub FormCheckout_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBoxVISA.Visible = False
        LabelVisa.Visible = False
        TextBoxVISA.Visible = False
        BtnOrder.Visible = False
    End Sub

    Private Sub RadioButtonVISA_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonVISA.CheckedChanged 'sub for making ComboBoxVISA visible and ButtonOrder invisible when RadioButtonVISA is checked
        If RadioButtonVISA.Checked Then
            ComboBoxVISA.Visible = True
            BtnOrder.Visible = False
        End If
    End Sub

    Private Sub ComboBoxVISA_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxVISA.SelectedIndexChanged 'when ComboBoxVISA selected index is changed
        If ComboBoxVISA.SelectedItem = "Online" Then 'if Online is selected, make LabelVisa, TextBoxVISA and ButtonOrder visible
            LabelVisa.Visible = True
            TextBoxVISA.Visible = True
            BtnOrder.Visible = True
        ElseIf ComboBoxVISA.SelectedItem = "On Pickup" Then 'if On Delivery is selected, make only Button Order visible
            BtnOrder.Visible = True
            LabelVisa.Visible = False
            TextBoxVISA.Visible = False
        Else 'if nothing is selected, make everything invisible
            LabelVisa.Visible = False
            TextBoxVISA.Visible = False
            BtnOrder.Visible = False
        End If
    End Sub

    Private Sub RadioButtonCash_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonCash.CheckedChanged 'when RadioButtonCash is checked
        If RadioButtonCash.Checked Then 'if it is checked, make ComboBoxVISA selected item into nothing, make it invisible, and make ButtonOrder visible
            ComboBoxVISA.SelectedItem = Nothing
            ComboBoxVISA.Visible = False
            BtnOrder.Visible = True
        End If
    End Sub


    Private Sub BtnOrder_Click(sender As Object, e As EventArgs) Handles BtnOrder.Click
        If RadioButtonCash.Checked OrElse ComboBoxVISA.SelectedItem = "On Pickup" OrElse TextBoxVISA.Text Like "#### #### #### ####" Then 'check if for every valid condition
            MessageBox.Show("Thank you for ordering" & vbCrLf & vbCrLf & "Total : " & OrderFood.TextBoxTotal.Text, "Order Successful")
        ElseIf Not TextBoxVISA.Text Like "#### #### #### ####" Then 'else if check if credit card number is invalid
            MessageBox.Show("Invalid Card Number" & vbCrLf & vbCrLf & "Card Number Should Be 16 Digits With A Space Between Every 4 Digits" & vbCrLf & vbCrLf & "Example: 1111 2222 3333 4444", "Order Unsuccessful")
        Else 'else
            MessageBox.Show("Invalid Payment Method", "Order Unsuccessful")
        End If
        Dim query As String = "insert into SalesTable values('" & getSName & "','" & DateTime.Today & "'," & Val(OrderFood.TextBoxTotal.Text) & ")"
        con.open()
        Dim cmd = New SqlCommand(query, con)
        cmd.ExecuteNonQuery()
        con.close()
    End Sub

    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub
End Class