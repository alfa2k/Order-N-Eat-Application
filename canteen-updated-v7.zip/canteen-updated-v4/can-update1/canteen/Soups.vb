﻿Public Class Soups
    Private Sub ButtonQ1Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ1Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceChicken, TextBoxQ1, CheckBoxEspresso)
    End Sub

    Private Sub ButtonQ1Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ1Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceChicken, TextBoxQ1, CheckBoxEspresso)
    End Sub

    Private Sub CheckBoxEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxEspresso.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxEspresso, Panel1, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ1, PriceChicken)
    End Sub



    Private Sub ButtonQ2Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ2Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCorn, TextBoxQ2, CheckBoxCorn)
    End Sub

    Private Sub ButtonQ2Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ2Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCorn, TextBoxQ2, CheckBoxCorn)
    End Sub

    Private Sub CheckBoxMacchiato_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxCorn.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxCorn, Panel2, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ2, PriceCorn)
    End Sub



    Private Sub ButtonQ3Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ3Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceMushroom, TextBoxQ3, CheckBoxMushroom)
    End Sub

    Private Sub ButtonQ3Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ3Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceMushroom, TextBoxQ3, CheckBoxMushroom)
    End Sub

    Private Sub CheckBoxAmericano_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxMushroom.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxMushroom, Panel3, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ3, PriceMushroom)
    End Sub



    Private Sub ButtonQ4Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ4Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceHotSour, TextBoxQ4, CheckBoxHotSour)
    End Sub

    Private Sub ButtonQ4Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ4Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceHotSour, TextBoxQ4, CheckBoxHotSour)
    End Sub

    Private Sub CheckBoxlatte_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxHotSour.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxHotSour, Panel4, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ4, PriceHotSour)
    End Sub



    Private Sub ButtonQ5Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ5Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceDal, TextBoxQ5, CheckBoxDal)
    End Sub

    Private Sub ButtonQ5Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ5Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceDal, TextBoxQ5, CheckBoxDal)
    End Sub

    Private Sub CheckBoxCappuccino_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxDal.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxDal, Panel5, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ5, PriceDal)
    End Sub



    Private Sub ButtonQ6Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ6Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceTomato, TextBoxQ6, CheckBoxTomato)
    End Sub

    Private Sub ButtonQ6Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ6Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceTomato, TextBoxQ6, CheckBoxTomato)
    End Sub

    Private Sub CheckBoxMocha_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxTomato.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxTomato, Panel6, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ6, PriceTomato)
    End Sub



    Private Sub HotCoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CanteenDashboard.QuantityVisibility(TextBoxQ1, Panel1)
        CanteenDashboard.QuantityVisibility(TextBoxQ2, Panel2)
        CanteenDashboard.QuantityVisibility(TextBoxQ3, Panel3)
        CanteenDashboard.QuantityVisibility(TextBoxQ4, Panel4)
        CanteenDashboard.QuantityVisibility(TextBoxQ5, Panel5)
        CanteenDashboard.QuantityVisibility(TextBoxQ6, Panel6)
    End Sub



    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub
End Class