﻿Public Class Soda
    Private Sub ButtonQ1Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ1Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PricePepsi, TextBoxQ1, CheckBoxPepsi)
    End Sub

    Private Sub ButtonQ1Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ1Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PricePepsi, TextBoxQ1, CheckBoxPepsi)
    End Sub

    Private Sub CheckBoxEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxPepsi.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxPepsi, Panel1, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ1, PricePepsi)
    End Sub



    Private Sub ButtonQ2Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ2Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceDew, TextBoxQ2, CheckBoxDew)
    End Sub

    Private Sub ButtonQ2Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ2Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceDew, TextBoxQ2, CheckBoxDew)
    End Sub

    Private Sub CheckBoxMacchiato_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxDew.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxDew, Panel2, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ2, PriceDew)
    End Sub



    Private Sub ButtonQ3Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ3Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceFanta, TextBoxQ3, CheckBoxFanta)
    End Sub

    Private Sub ButtonQ3Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ3Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceFanta, TextBoxQ3, CheckBoxFanta)
    End Sub

    Private Sub CheckBoxAmericano_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxFanta.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxFanta, Panel3, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ3, PriceFanta)
    End Sub



    Private Sub ButtonQ4Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ4Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceFanta2, TextBoxQ4, CheckBoxFanta2)
    End Sub

    Private Sub ButtonQ4Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ4Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceFanta2, TextBoxQ4, CheckBoxFanta2)
    End Sub

    Private Sub CheckBoxlatte_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxFanta2.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxFanta2, Panel4, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ4, PriceFanta2)
    End Sub



    Private Sub ButtonQ5Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ5Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceSprite, TextBoxQ5, CheckBoxSprite)
    End Sub

    Private Sub ButtonQ5Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ5Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceSprite, TextBoxQ5, CheckBoxSprite)
    End Sub

    Private Sub CheckBoxCappuccino_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxSprite.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxSprite, Panel5, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ5, PriceSprite)
    End Sub



    Private Sub ButtonQ6Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ6Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, Price7UP, TextBoxQ6, CheckBox7UP)
    End Sub

    Private Sub ButtonQ6Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ6Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, Price7UP, TextBoxQ6, CheckBox7UP)
    End Sub

    Private Sub CheckBoxMocha_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox7UP.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBox7UP, Panel6, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ6, Price7UP)
    End Sub



    Private Sub HotCoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CanteenDashboard.QuantityVisibility(TextBoxQ1, Panel1)
        CanteenDashboard.QuantityVisibility(TextBoxQ2, Panel2)
        CanteenDashboard.QuantityVisibility(TextBoxQ3, Panel3)
        CanteenDashboard.QuantityVisibility(TextBoxQ4, Panel4)
        CanteenDashboard.QuantityVisibility(TextBoxQ5, Panel5)
        CanteenDashboard.QuantityVisibility(TextBoxQ6, Panel6)
    End Sub



    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub
End Class