﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Breakfast
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBoxQ6 = New System.Windows.Forms.TextBox()
        Me.ButtonQ1Inc = New System.Windows.Forms.Button()
        Me.CheckBoxSausageEgg = New System.Windows.Forms.CheckBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PriceChickenEgg = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBoxQ3 = New System.Windows.Forms.TextBox()
        Me.ButtonQ3Inc = New System.Windows.Forms.Button()
        Me.ButtonQ3Dec = New System.Windows.Forms.Button()
        Me.PricePotatoWaffle = New System.Windows.Forms.Label()
        Me.PriceChocoWaffle = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ButtonQ4Inc = New System.Windows.Forms.Button()
        Me.ButtonQ4Dec = New System.Windows.Forms.Button()
        Me.CheckBoxPotatoWaffle = New System.Windows.Forms.CheckBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.CheckBoxChocoWaffle = New System.Windows.Forms.CheckBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBoxQ2 = New System.Windows.Forms.TextBox()
        Me.ButtonQ2Inc = New System.Windows.Forms.Button()
        Me.ButtonQ2Dec = New System.Windows.Forms.Button()
        Me.CheckBoxPancake = New System.Windows.Forms.CheckBox()
        Me.TextBoxQ1 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ButtonQ1Dec = New System.Windows.Forms.Button()
        Me.ButtonQ6Inc = New System.Windows.Forms.Button()
        Me.CheckBoxChickenEgg = New System.Windows.Forms.CheckBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PriceCherryPancake = New System.Windows.Forms.Label()
        Me.CheckBoxCherryPancake = New System.Windows.Forms.CheckBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBoxQ5 = New System.Windows.Forms.TextBox()
        Me.ButtonQ5Inc = New System.Windows.Forms.Button()
        Me.ButtonQ5Dec = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TextBoxQ4 = New System.Windows.Forms.TextBox()
        Me.PricePancake = New System.Windows.Forms.Label()
        Me.PriceSausageEgg = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.ButtonQ6Dec = New System.Windows.Forms.Button()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBoxQ6
        '
        Me.TextBoxQ6.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ6.Enabled = False
        Me.TextBoxQ6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ6.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ6.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ6.Name = "TextBoxQ6"
        Me.TextBoxQ6.ReadOnly = True
        Me.TextBoxQ6.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ6.TabIndex = 2
        Me.TextBoxQ6.TabStop = False
        Me.TextBoxQ6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ1Inc
        '
        Me.ButtonQ1Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ1Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ1Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ1Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ1Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ1Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ1Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ1Inc.Name = "ButtonQ1Inc"
        Me.ButtonQ1Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ1Inc.TabIndex = 1
        Me.ButtonQ1Inc.TabStop = False
        Me.ButtonQ1Inc.Text = "+"
        Me.ButtonQ1Inc.UseVisualStyleBackColor = True
        '
        'CheckBoxSausageEgg
        '
        Me.CheckBoxSausageEgg.AutoSize = True
        Me.CheckBoxSausageEgg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxSausageEgg.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxSausageEgg.ForeColor = System.Drawing.Color.White
        Me.CheckBoxSausageEgg.Location = New System.Drawing.Point(736, 810)
        Me.CheckBoxSausageEgg.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxSausageEgg.Name = "CheckBoxSausageEgg"
        Me.CheckBoxSausageEgg.Size = New System.Drawing.Size(310, 36)
        Me.CheckBoxSausageEgg.TabIndex = 97
        Me.CheckBoxSausageEgg.TabStop = False
        Me.CheckBoxSausageEgg.Text = "Sausage Egg Cheese"
        Me.CheckBoxSausageEgg.UseVisualStyleBackColor = True
        '
        'PictureBox6
        '
        Me.PictureBox6.Location = New System.Drawing.Point(795, 595)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 96
        Me.PictureBox6.TabStop = False
        '
        'PriceChickenEgg
        '
        Me.PriceChickenEgg.AutoSize = True
        Me.PriceChickenEgg.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceChickenEgg.ForeColor = System.Drawing.Color.White
        Me.PriceChickenEgg.Location = New System.Drawing.Point(489, 859)
        Me.PriceChickenEgg.Name = "PriceChickenEgg"
        Me.PriceChickenEgg.Size = New System.Drawing.Size(103, 38)
        Me.PriceChickenEgg.TabIndex = 95
        Me.PriceChickenEgg.Text = "1 OMR"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.TextBoxQ3)
        Me.Panel3.Controls.Add(Me.ButtonQ3Inc)
        Me.Panel3.Controls.Add(Me.ButtonQ3Dec)
        Me.Panel3.Location = New System.Drawing.Point(771, 434)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(232, 72)
        Me.Panel3.TabIndex = 86
        '
        'TextBoxQ3
        '
        Me.TextBoxQ3.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ3.Enabled = False
        Me.TextBoxQ3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ3.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ3.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ3.Name = "TextBoxQ3"
        Me.TextBoxQ3.ReadOnly = True
        Me.TextBoxQ3.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ3.TabIndex = 2
        Me.TextBoxQ3.TabStop = False
        Me.TextBoxQ3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ3Inc
        '
        Me.ButtonQ3Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ3Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ3Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ3Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ3Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ3Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ3Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ3Inc.Name = "ButtonQ3Inc"
        Me.ButtonQ3Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ3Inc.TabIndex = 1
        Me.ButtonQ3Inc.TabStop = False
        Me.ButtonQ3Inc.Text = "+"
        Me.ButtonQ3Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ3Dec
        '
        Me.ButtonQ3Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ3Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ3Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ3Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ3Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ3Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ3Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ3Dec.Name = "ButtonQ3Dec"
        Me.ButtonQ3Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ3Dec.TabIndex = 0
        Me.ButtonQ3Dec.TabStop = False
        Me.ButtonQ3Dec.Text = "-"
        Me.ButtonQ3Dec.UseVisualStyleBackColor = True
        '
        'PricePotatoWaffle
        '
        Me.PricePotatoWaffle.AutoSize = True
        Me.PricePotatoWaffle.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PricePotatoWaffle.ForeColor = System.Drawing.Color.White
        Me.PricePotatoWaffle.Location = New System.Drawing.Point(480, 371)
        Me.PricePotatoWaffle.Name = "PricePotatoWaffle"
        Me.PricePotatoWaffle.Size = New System.Drawing.Size(139, 38)
        Me.PricePotatoWaffle.TabIndex = 83
        Me.PricePotatoWaffle.Text = "0.75 OMR"
        '
        'PriceChocoWaffle
        '
        Me.PriceChocoWaffle.AutoSize = True
        Me.PriceChocoWaffle.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceChocoWaffle.ForeColor = System.Drawing.Color.White
        Me.PriceChocoWaffle.Location = New System.Drawing.Point(128, 371)
        Me.PriceChocoWaffle.Name = "PriceChocoWaffle"
        Me.PriceChocoWaffle.Size = New System.Drawing.Size(139, 38)
        Me.PriceChocoWaffle.TabIndex = 79
        Me.PriceChocoWaffle.Text = "0.75 OMR"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(109, 107)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 76
        Me.PictureBox1.TabStop = False
        '
        'ButtonQ4Inc
        '
        Me.ButtonQ4Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ4Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ4Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ4Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ4Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ4Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ4Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ4Inc.Name = "ButtonQ4Inc"
        Me.ButtonQ4Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ4Inc.TabIndex = 1
        Me.ButtonQ4Inc.TabStop = False
        Me.ButtonQ4Inc.Text = "+"
        Me.ButtonQ4Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ4Dec
        '
        Me.ButtonQ4Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ4Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ4Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ4Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ4Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ4Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ4Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ4Dec.Name = "ButtonQ4Dec"
        Me.ButtonQ4Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ4Dec.TabIndex = 0
        Me.ButtonQ4Dec.TabStop = False
        Me.ButtonQ4Dec.Text = "-"
        Me.ButtonQ4Dec.UseVisualStyleBackColor = True
        '
        'CheckBoxPotatoWaffle
        '
        Me.CheckBoxPotatoWaffle.AutoSize = True
        Me.CheckBoxPotatoWaffle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxPotatoWaffle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxPotatoWaffle.ForeColor = System.Drawing.Color.White
        Me.CheckBoxPotatoWaffle.Location = New System.Drawing.Point(439, 323)
        Me.CheckBoxPotatoWaffle.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxPotatoWaffle.Name = "CheckBoxPotatoWaffle"
        Me.CheckBoxPotatoWaffle.Size = New System.Drawing.Size(205, 36)
        Me.CheckBoxPotatoWaffle.TabIndex = 81
        Me.CheckBoxPotatoWaffle.TabStop = False
        Me.CheckBoxPotatoWaffle.Text = "Potato Waffle"
        Me.CheckBoxPotatoWaffle.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(457, 107)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 80
        Me.PictureBox2.TabStop = False
        '
        'CheckBoxChocoWaffle
        '
        Me.CheckBoxChocoWaffle.AutoSize = True
        Me.CheckBoxChocoWaffle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxChocoWaffle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxChocoWaffle.ForeColor = System.Drawing.Color.White
        Me.CheckBoxChocoWaffle.Location = New System.Drawing.Point(83, 322)
        Me.CheckBoxChocoWaffle.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxChocoWaffle.Name = "CheckBoxChocoWaffle"
        Me.CheckBoxChocoWaffle.Size = New System.Drawing.Size(251, 36)
        Me.CheckBoxChocoWaffle.TabIndex = 77
        Me.CheckBoxChocoWaffle.TabStop = False
        Me.CheckBoxChocoWaffle.Text = "Chocolate Waffle"
        Me.CheckBoxChocoWaffle.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(795, 107)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 84
        Me.PictureBox3.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TextBoxQ2)
        Me.Panel2.Controls.Add(Me.ButtonQ2Inc)
        Me.Panel2.Controls.Add(Me.ButtonQ2Dec)
        Me.Panel2.Location = New System.Drawing.Point(431, 434)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(232, 72)
        Me.Panel2.TabIndex = 82
        '
        'TextBoxQ2
        '
        Me.TextBoxQ2.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ2.Enabled = False
        Me.TextBoxQ2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ2.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ2.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ2.Name = "TextBoxQ2"
        Me.TextBoxQ2.ReadOnly = True
        Me.TextBoxQ2.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ2.TabIndex = 2
        Me.TextBoxQ2.TabStop = False
        Me.TextBoxQ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ2Inc
        '
        Me.ButtonQ2Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ2Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ2Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ2Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ2Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ2Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ2Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ2Inc.Name = "ButtonQ2Inc"
        Me.ButtonQ2Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ2Inc.TabIndex = 1
        Me.ButtonQ2Inc.TabStop = False
        Me.ButtonQ2Inc.Text = "+"
        Me.ButtonQ2Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ2Dec
        '
        Me.ButtonQ2Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ2Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ2Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ2Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ2Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ2Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ2Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ2Dec.Name = "ButtonQ2Dec"
        Me.ButtonQ2Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ2Dec.TabIndex = 0
        Me.ButtonQ2Dec.TabStop = False
        Me.ButtonQ2Dec.Text = "-"
        Me.ButtonQ2Dec.UseVisualStyleBackColor = True
        '
        'CheckBoxPancake
        '
        Me.CheckBoxPancake.AutoSize = True
        Me.CheckBoxPancake.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxPancake.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxPancake.ForeColor = System.Drawing.Color.White
        Me.CheckBoxPancake.Location = New System.Drawing.Point(760, 322)
        Me.CheckBoxPancake.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxPancake.Name = "CheckBoxPancake"
        Me.CheckBoxPancake.Size = New System.Drawing.Size(252, 36)
        Me.CheckBoxPancake.TabIndex = 85
        Me.CheckBoxPancake.TabStop = False
        Me.CheckBoxPancake.Text = "Original Pancake"
        Me.CheckBoxPancake.UseVisualStyleBackColor = True
        '
        'TextBoxQ1
        '
        Me.TextBoxQ1.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ1.Enabled = False
        Me.TextBoxQ1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ1.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ1.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ1.Name = "TextBoxQ1"
        Me.TextBoxQ1.ReadOnly = True
        Me.TextBoxQ1.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ1.TabIndex = 2
        Me.TextBoxQ1.TabStop = False
        Me.TextBoxQ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TextBoxQ1)
        Me.Panel1.Controls.Add(Me.ButtonQ1Inc)
        Me.Panel1.Controls.Add(Me.ButtonQ1Dec)
        Me.Panel1.Location = New System.Drawing.Point(83, 434)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(232, 72)
        Me.Panel1.TabIndex = 78
        '
        'ButtonQ1Dec
        '
        Me.ButtonQ1Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ1Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ1Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ1Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ1Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ1Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ1Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ1Dec.Name = "ButtonQ1Dec"
        Me.ButtonQ1Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ1Dec.TabIndex = 0
        Me.ButtonQ1Dec.TabStop = False
        Me.ButtonQ1Dec.Text = "-"
        Me.ButtonQ1Dec.UseVisualStyleBackColor = True
        '
        'ButtonQ6Inc
        '
        Me.ButtonQ6Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ6Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ6Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ6Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ6Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ6Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ6Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ6Inc.Name = "ButtonQ6Inc"
        Me.ButtonQ6Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ6Inc.TabIndex = 1
        Me.ButtonQ6Inc.TabStop = False
        Me.ButtonQ6Inc.Text = "+"
        Me.ButtonQ6Inc.UseVisualStyleBackColor = True
        '
        'CheckBoxChickenEgg
        '
        Me.CheckBoxChickenEgg.AutoSize = True
        Me.CheckBoxChickenEgg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxChickenEgg.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxChickenEgg.ForeColor = System.Drawing.Color.White
        Me.CheckBoxChickenEgg.Location = New System.Drawing.Point(406, 810)
        Me.CheckBoxChickenEgg.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxChickenEgg.Name = "CheckBoxChickenEgg"
        Me.CheckBoxChickenEgg.Size = New System.Drawing.Size(300, 36)
        Me.CheckBoxChickenEgg.TabIndex = 93
        Me.CheckBoxChickenEgg.TabStop = False
        Me.CheckBoxChickenEgg.Text = "Chicken Egg Cheese"
        Me.CheckBoxChickenEgg.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.Location = New System.Drawing.Point(457, 595)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 92
        Me.PictureBox5.TabStop = False
        '
        'PriceCherryPancake
        '
        Me.PriceCherryPancake.AutoSize = True
        Me.PriceCherryPancake.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceCherryPancake.ForeColor = System.Drawing.Color.White
        Me.PriceCherryPancake.Location = New System.Drawing.Point(128, 859)
        Me.PriceCherryPancake.Name = "PriceCherryPancake"
        Me.PriceCherryPancake.Size = New System.Drawing.Size(139, 38)
        Me.PriceCherryPancake.TabIndex = 91
        Me.PriceCherryPancake.Text = "0.75 OMR"
        '
        'CheckBoxCherryPancake
        '
        Me.CheckBoxCherryPancake.AutoSize = True
        Me.CheckBoxCherryPancake.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxCherryPancake.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxCherryPancake.ForeColor = System.Drawing.Color.White
        Me.CheckBoxCherryPancake.Location = New System.Drawing.Point(39, 810)
        Me.CheckBoxCherryPancake.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxCherryPancake.Name = "CheckBoxCherryPancake"
        Me.CheckBoxCherryPancake.Size = New System.Drawing.Size(342, 36)
        Me.CheckBoxCherryPancake.TabIndex = 89
        Me.CheckBoxCherryPancake.TabStop = False
        Me.CheckBoxCherryPancake.Text = "Cherry-Topped Pancake"
        Me.CheckBoxCherryPancake.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Location = New System.Drawing.Point(109, 595)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 88
        Me.PictureBox4.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.TextBoxQ5)
        Me.Panel5.Controls.Add(Me.ButtonQ5Inc)
        Me.Panel5.Controls.Add(Me.ButtonQ5Dec)
        Me.Panel5.Location = New System.Drawing.Point(431, 921)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(232, 72)
        Me.Panel5.TabIndex = 94
        '
        'TextBoxQ5
        '
        Me.TextBoxQ5.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ5.Enabled = False
        Me.TextBoxQ5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ5.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ5.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ5.Name = "TextBoxQ5"
        Me.TextBoxQ5.ReadOnly = True
        Me.TextBoxQ5.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ5.TabIndex = 2
        Me.TextBoxQ5.TabStop = False
        Me.TextBoxQ5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ5Inc
        '
        Me.ButtonQ5Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ5Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ5Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ5Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ5Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ5Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ5Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ5Inc.Name = "ButtonQ5Inc"
        Me.ButtonQ5Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ5Inc.TabIndex = 1
        Me.ButtonQ5Inc.TabStop = False
        Me.ButtonQ5Inc.Text = "+"
        Me.ButtonQ5Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ5Dec
        '
        Me.ButtonQ5Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ5Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ5Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ5Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ5Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ5Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ5Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ5Dec.Name = "ButtonQ5Dec"
        Me.ButtonQ5Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ5Dec.TabIndex = 0
        Me.ButtonQ5Dec.TabStop = False
        Me.ButtonQ5Dec.Text = "-"
        Me.ButtonQ5Dec.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.TextBoxQ4)
        Me.Panel4.Controls.Add(Me.ButtonQ4Inc)
        Me.Panel4.Controls.Add(Me.ButtonQ4Dec)
        Me.Panel4.Location = New System.Drawing.Point(83, 921)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(232, 72)
        Me.Panel4.TabIndex = 90
        '
        'TextBoxQ4
        '
        Me.TextBoxQ4.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ4.Enabled = False
        Me.TextBoxQ4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ4.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ4.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ4.Name = "TextBoxQ4"
        Me.TextBoxQ4.ReadOnly = True
        Me.TextBoxQ4.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ4.TabIndex = 2
        Me.TextBoxQ4.TabStop = False
        Me.TextBoxQ4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PricePancake
        '
        Me.PricePancake.AutoSize = True
        Me.PricePancake.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PricePancake.ForeColor = System.Drawing.Color.White
        Me.PricePancake.Location = New System.Drawing.Point(816, 371)
        Me.PricePancake.Name = "PricePancake"
        Me.PricePancake.Size = New System.Drawing.Size(139, 38)
        Me.PricePancake.TabIndex = 87
        Me.PricePancake.Text = "0.75 OMR"
        '
        'PriceSausageEgg
        '
        Me.PriceSausageEgg.AutoSize = True
        Me.PriceSausageEgg.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceSausageEgg.ForeColor = System.Drawing.Color.White
        Me.PriceSausageEgg.Location = New System.Drawing.Point(829, 859)
        Me.PriceSausageEgg.Name = "PriceSausageEgg"
        Me.PriceSausageEgg.Size = New System.Drawing.Size(103, 38)
        Me.PriceSausageEgg.TabIndex = 99
        Me.PriceSausageEgg.Text = "1 OMR"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.TextBoxQ6)
        Me.Panel6.Controls.Add(Me.ButtonQ6Inc)
        Me.Panel6.Controls.Add(Me.ButtonQ6Dec)
        Me.Panel6.Location = New System.Drawing.Point(771, 921)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(232, 72)
        Me.Panel6.TabIndex = 98
        '
        'ButtonQ6Dec
        '
        Me.ButtonQ6Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ6Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ6Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ6Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ6Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ6Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ6Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ6Dec.Name = "ButtonQ6Dec"
        Me.ButtonQ6Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ6Dec.TabIndex = 0
        Me.ButtonQ6Dec.TabStop = False
        Me.ButtonQ6Dec.Text = "-"
        Me.ButtonQ6Dec.UseVisualStyleBackColor = True
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Breakfast
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1086, 1101)
        Me.Controls.Add(Me.CheckBoxSausageEgg)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PriceChickenEgg)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.PricePotatoWaffle)
        Me.Controls.Add(Me.PriceChocoWaffle)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CheckBoxPotatoWaffle)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.CheckBoxChocoWaffle)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.CheckBoxPancake)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CheckBoxChickenEgg)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PriceCherryPancake)
        Me.Controls.Add(Me.CheckBoxCherryPancake)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.PricePancake)
        Me.Controls.Add(Me.PriceSausageEgg)
        Me.Controls.Add(Me.Panel6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Name = "Breakfast"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Breakfast"
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxQ6 As TextBox
    Friend WithEvents ButtonQ1Inc As Button
    Friend WithEvents CheckBoxSausageEgg As CheckBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PriceChickenEgg As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBoxQ3 As TextBox
    Friend WithEvents ButtonQ3Inc As Button
    Friend WithEvents ButtonQ3Dec As Button
    Friend WithEvents PricePotatoWaffle As Label
    Friend WithEvents PriceChocoWaffle As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ButtonQ4Inc As Button
    Friend WithEvents ButtonQ4Dec As Button
    Friend WithEvents CheckBoxPotatoWaffle As CheckBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents CheckBoxChocoWaffle As CheckBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBoxQ2 As TextBox
    Friend WithEvents ButtonQ2Inc As Button
    Friend WithEvents ButtonQ2Dec As Button
    Friend WithEvents CheckBoxPancake As CheckBox
    Friend WithEvents TextBoxQ1 As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ButtonQ1Dec As Button
    Friend WithEvents ButtonQ6Inc As Button
    Friend WithEvents CheckBoxChickenEgg As CheckBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PriceCherryPancake As Label
    Friend WithEvents CheckBoxCherryPancake As CheckBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBoxQ5 As TextBox
    Friend WithEvents ButtonQ5Inc As Button
    Friend WithEvents ButtonQ5Dec As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBoxQ4 As TextBox
    Friend WithEvents PricePancake As Label
    Friend WithEvents PriceSausageEgg As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents ButtonQ6Dec As Button
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
End Class
