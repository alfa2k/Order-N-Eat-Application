﻿Public Class CanteenDashboard


    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles btnSignout.Click
        Me.Hide()
        LoginPage.Show()

    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles BtnManageOrders.Click

        Orders.Show()

    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles btnInventory.Click

        InventoryForm.Show()

    End Sub

    Private Sub btnOrderFood_Click(sender As Object, e As EventArgs) Handles btnOrderFood.Click
        OrderFood.Show()

    End Sub

    Private Sub btnOrderDrinks_Click(sender As Object, e As EventArgs) Handles btnOrderDrinks.Click
        OrderDrinks.Show()

    End Sub

    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) Handles Guna2ControlBox1.Click
        Application.Exit()
    End Sub

    Private Sub btnManageSales_Click(sender As Object, e As EventArgs) Handles btnManageSales.Click
        MessageBox.Show("Loading")
        SaleManagement.Show()
    End Sub

    Private Sub btnReportPage_Click(sender As Object, e As EventArgs) Handles btnReportPage.Click
        MessageBox.Show("Loading")
        Overview.Show()
    End Sub

    Private Sub btnNotification_Click(sender As Object, e As EventArgs) Handles btnNotification.Click
        MessageBox.Show("Loading")
    End Sub

    Public Sub increase(ListBox As ListBox, Total As TextBox, Price As Label, Quantity As TextBox, Item As CheckBox)
        Quantity.Text = Val(Quantity.Text) + 1
        Total.Text = Val(Total.Text) + Val(Price.Text) & " OMR"
        ListBox.Items.Remove(Val(Quantity.Text) - 1 & " " & Item.Text & " " & Val(Price.Text) * Val(Quantity.Text) - Val(Price.Text) & " OMR")
        ListBox.Items.Add(Val(Quantity.Text) & " " & Item.Text & " " & Val(Price.Text) * Val(Quantity.Text) & " OMR")
    End Sub

    Public Sub decrease(ListBox As ListBox, Total As TextBox, Price As Label, Quantity As TextBox, Item As CheckBox)
        If Not Val(Quantity.Text) <= 1 Then
            Quantity.Text = Val(Quantity.Text) - 1
            Total.Text = Val(Total.Text) - Val(Price.Text) & " OMR"
            ListBox.Items.Remove(Val(Quantity.Text) + 1 & " " & Item.Text & " " & Val(Price.Text) * Val(Quantity.Text) + Val(Price.Text) & " OMR")
            ListBox.Items.Add(Val(Quantity.Text) & " " & Item.Text & " " & Val(Price.Text) * Val(Quantity.Text) & " OMR")
        End If
    End Sub

    Public Sub checkingAnItem(Item As CheckBox, Panel As Panel, Total As TextBox, ListBox As ListBox, Quantity As TextBox, Price As Label)
        If Item.Checked Then
            Panel.Visible = True
            Total.Text = Val(Total.Text) + Val(Price.Text) & " OMR"
            ListBox.Items.Add(Val(Quantity.Text) & " " & Item.Text & " " & Val(Price.Text) * Val(Quantity.Text) & " OMR")
        Else
            Panel.Visible = False
            Total.Text = Val(Total.Text) - Val(Price.Text) * Val(Quantity.Text) & " OMR"
            ListBox.Items.Remove(Val(Quantity.Text) & " " & Item.Text & " " & Val(Price.Text) * Val(Quantity.Text) & " OMR")
            Quantity.Text = "1"
        End If
    End Sub

    Public Sub QuantityVisibility(Quantity As TextBox, Panel As Panel)
        Quantity.Text = "1"
        Panel.Visible = False
    End Sub

    Private Sub TimerToday_Tick(sender As Object, e As EventArgs) Handles TimerToday.Tick
        lblTime.Text = TimeOfDay.ToString("h:mm:ss tt")
    End Sub


End Class
