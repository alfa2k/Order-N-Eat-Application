﻿Public Class Juice
    Private Sub ButtonQ1Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ1Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceApple, TextBoxQ1, CheckBoxApple)
    End Sub

    Private Sub ButtonQ1Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ1Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceApple, TextBoxQ1, CheckBoxApple)
    End Sub

    Private Sub CheckBoxEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxApple.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxApple, Panel1, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ1, PriceApple)
    End Sub



    Private Sub ButtonQ2Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ2Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceOrange, TextBoxQ2, CheckBoxOrange)
    End Sub

    Private Sub ButtonQ2Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ2Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceOrange, TextBoxQ2, CheckBoxOrange)
    End Sub

    Private Sub CheckBoxMacchiato_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxOrange.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxOrange, Panel2, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ2, PriceOrange)
    End Sub



    Private Sub ButtonQ3Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ3Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceWatermelon, TextBoxQ3, CheckBoxWatermelon)
    End Sub

    Private Sub ButtonQ3Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ3Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceWatermelon, TextBoxQ3, CheckBoxWatermelon)
    End Sub

    Private Sub CheckBoxAmericano_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxWatermelon.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxWatermelon, Panel3, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ3, PriceWatermelon)
    End Sub



    Private Sub ButtonQ4Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ4Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceLemon, TextBoxQ4, CheckBoxLemon)
    End Sub

    Private Sub ButtonQ4Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ4Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceLemon, TextBoxQ4, CheckBoxLemon)
    End Sub

    Private Sub CheckBoxlatte_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxLemon.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxLemon, Panel4, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ4, PriceLemon)
    End Sub



    Private Sub ButtonQ5Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ5Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PricePineapple, TextBoxQ5, CheckBoxPineapple)
    End Sub

    Private Sub ButtonQ5Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ5Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PricePineapple, TextBoxQ5, CheckBoxPineapple)
    End Sub

    Private Sub CheckBoxCappuccino_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxPineapple.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxPineapple, Panel5, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ5, PricePineapple)
    End Sub



    Private Sub ButtonQ6Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ6Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PricePear, TextBoxQ6, CheckBoxPear)
    End Sub

    Private Sub ButtonQ6Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ6Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PricePear, TextBoxQ6, CheckBoxPear)
    End Sub

    Private Sub CheckBoxMocha_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxPear.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxPear, Panel6, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ6, PricePear)
    End Sub



    Private Sub HotCoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CanteenDashboard.QuantityVisibility(TextBoxQ1, Panel1)
        CanteenDashboard.QuantityVisibility(TextBoxQ2, Panel2)
        CanteenDashboard.QuantityVisibility(TextBoxQ3, Panel3)
        CanteenDashboard.QuantityVisibility(TextBoxQ4, Panel4)
        CanteenDashboard.QuantityVisibility(TextBoxQ5, Panel5)
        CanteenDashboard.QuantityVisibility(TextBoxQ6, Panel6)
    End Sub



    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub
End Class