﻿Imports System.Data.SqlClient

Public Class InventoryForm

    Dim con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v4\can-update1\canteen\Management1.mdf;Integrated Security=True")
    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) Handles Guna2ControlBox1.Click
        Me.Close()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        If CategoryAddToTable.Text = "" Then
            MessageBox.Show("Enter the Category")
        Else
            con.open()
            Dim query = "insert into CategoryTable values('" & CategoryAddToTable.Text & "')"
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Category Added")
            con.close()
            CategoryAddToTable.Text = ""
            fillCategory()
        End If

    End Sub

    Private Sub reset()
        comboboxCategory.SelectedIndex = 0
        txtboxItemName.Text = ""
        txtboxItemPrice.Text = ""
        txtboxQuantity.Text = ""
    End Sub

    Private Sub fillCategory()
        con.open()
        Dim cmd = New SqlCommand("select * from CategoryTable", con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim table = New DataTable()
        adapter.Fill(table)
        comboboxCategory.DataSource = table
        comboboxCategory.DisplayMember = "CategoryName"
        comboboxCategory.ValueMember = "CategoryName"
        con.close()
    End Sub

    Private Sub ResetItems_Click(sender As Object, e As EventArgs) Handles ResetItems.Click
        reset()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillCategory()
        displayItem()
    End Sub

    Private Sub displayItem()
        con.open()
        Dim query = "select * from ItemTable"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        ItemsDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub

    Private Sub AddIetm_Click(sender As Object, e As EventArgs) Handles AddIetm.Click
        If comboboxCategory.SelectedIndex = -1 Or txtboxItemName.Text = "" Or txtboxItemPrice.Text = "" Or txtboxQuantity.Text = "" Then
            MessageBox.Show("Please Enter All the Fields")
        Else
            con.open()
            Dim query = "insert into ItemTable values('" & txtboxItemName.Text & "','" & comboboxCategory.SelectedValue.ToString() & "'," & txtboxItemPrice.Text & "," & txtboxQuantity.Text & ")"
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Item Added into Inventory")
            con.close()
            reset()
            displayItem()
            'CategoryAddToTable.Text = ""
            'fillCategory()
        End If
    End Sub

    Dim key = 0
    Private Sub ItemsDGV_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles ItemsDGV.CellMouseClick
        Dim row As DataGridViewRow = ItemsDGV.Rows(e.RowIndex)
        txtboxItemName.Text = row.Cells(1).Value.ToString
        comboboxCategory.SelectedValue = row.Cells(2).Value.ToString
        txtboxItemPrice.Text = row.Cells(3).Value.ToString
        txtboxQuantity.Text = row.Cells(4).Value.ToString

        If txtboxItemName.Text = "" Then
            key = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
        End If
    End Sub

    Private Sub DeleteItem_Click(sender As Object, e As EventArgs) Handles DeleteItem.Click
        If key = 0 Then
            MessageBox.Show("Please Select The Field To Be Deleted")
        Else
            con.open()
            Dim query = "delete from ItemTable where ItemID=" & key & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Item Deleted Successfully")
            con.close()
            reset()
            displayItem()
        End If
    End Sub

    Private Sub EditItem_Click(sender As Object, e As EventArgs) Handles EditItem.Click
        If comboboxCategory.SelectedIndex = -1 Or txtboxItemName.Text = "" Or txtboxItemPrice.Text = "" Or txtboxQuantity.Text = "" Then
            MessageBox.Show("Please Enter All the Fields")
        Else
            con.open()
            Dim query = "update ItemTable set ItemName='" & txtboxItemName.Text & "',ItemCategory='" & comboboxCategory.SelectedValue.ToString() & "',ItemPrice=" & txtboxItemPrice.Text & ",ItemQuantity=" & txtboxQuantity.Text & " where ItemID=" & key & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Item Updated")
            con.close()
            reset()
            displayItem()
            'CategoryAddToTable.Text = ""
            'fillCategory()
        End If
    End Sub
End Class