﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Salads
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBoxQ6 = New System.Windows.Forms.TextBox()
        Me.ButtonQ1Inc = New System.Windows.Forms.Button()
        Me.CheckBoxMocha = New System.Windows.Forms.CheckBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PriceAsian = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBoxQ3 = New System.Windows.Forms.TextBox()
        Me.ButtonQ3Inc = New System.Windows.Forms.Button()
        Me.ButtonQ3Dec = New System.Windows.Forms.Button()
        Me.PriceGreek = New System.Windows.Forms.Label()
        Me.PriceCaesar = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ButtonQ4Inc = New System.Windows.Forms.Button()
        Me.ButtonQ4Dec = New System.Windows.Forms.Button()
        Me.CheckBoxMacchiato = New System.Windows.Forms.CheckBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.CheckBoxCaesar = New System.Windows.Forms.CheckBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBoxQ2 = New System.Windows.Forms.TextBox()
        Me.ButtonQ2Inc = New System.Windows.Forms.Button()
        Me.ButtonQ2Dec = New System.Windows.Forms.Button()
        Me.CheckBoxAmericano = New System.Windows.Forms.CheckBox()
        Me.TextBoxQ1 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ButtonQ1Dec = New System.Windows.Forms.Button()
        Me.ButtonQ6Inc = New System.Windows.Forms.Button()
        Me.CheckBoxAsian = New System.Windows.Forms.CheckBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PriceCrab = New System.Windows.Forms.Label()
        Me.CheckBoxCrab = New System.Windows.Forms.CheckBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBoxQ5 = New System.Windows.Forms.TextBox()
        Me.ButtonQ5Inc = New System.Windows.Forms.Button()
        Me.ButtonQ5Dec = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TextBoxQ4 = New System.Windows.Forms.TextBox()
        Me.PriceAmericano = New System.Windows.Forms.Label()
        Me.PriceVeggie = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.ButtonQ6Dec = New System.Windows.Forms.Button()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBoxQ6
        '
        Me.TextBoxQ6.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ6.Enabled = False
        Me.TextBoxQ6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ6.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ6.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ6.Name = "TextBoxQ6"
        Me.TextBoxQ6.ReadOnly = True
        Me.TextBoxQ6.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ6.TabIndex = 2
        Me.TextBoxQ6.TabStop = False
        Me.TextBoxQ6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ1Inc
        '
        Me.ButtonQ1Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ1Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ1Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ1Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ1Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ1Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ1Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ1Inc.Name = "ButtonQ1Inc"
        Me.ButtonQ1Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ1Inc.TabIndex = 1
        Me.ButtonQ1Inc.TabStop = False
        Me.ButtonQ1Inc.Text = "+"
        Me.ButtonQ1Inc.UseVisualStyleBackColor = True
        '
        'CheckBoxMocha
        '
        Me.CheckBoxMocha.AutoSize = True
        Me.CheckBoxMocha.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxMocha.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxMocha.ForeColor = System.Drawing.Color.White
        Me.CheckBoxMocha.Location = New System.Drawing.Point(783, 811)
        Me.CheckBoxMocha.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxMocha.Name = "CheckBoxMocha"
        Me.CheckBoxMocha.Size = New System.Drawing.Size(205, 36)
        Me.CheckBoxMocha.TabIndex = 97
        Me.CheckBoxMocha.TabStop = False
        Me.CheckBoxMocha.Text = "Veggie Salad"
        Me.CheckBoxMocha.UseVisualStyleBackColor = True
        '
        'PictureBox6
        '
        Me.PictureBox6.Location = New System.Drawing.Point(795, 595)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 96
        Me.PictureBox6.TabStop = False
        '
        'PriceAsian
        '
        Me.PriceAsian.AutoSize = True
        Me.PriceAsian.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceAsian.ForeColor = System.Drawing.Color.White
        Me.PriceAsian.Location = New System.Drawing.Point(478, 859)
        Me.PriceAsian.Name = "PriceAsian"
        Me.PriceAsian.Size = New System.Drawing.Size(139, 38)
        Me.PriceAsian.TabIndex = 95
        Me.PriceAsian.Text = "0.75 OMR"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.TextBoxQ3)
        Me.Panel3.Controls.Add(Me.ButtonQ3Inc)
        Me.Panel3.Controls.Add(Me.ButtonQ3Dec)
        Me.Panel3.Location = New System.Drawing.Point(771, 434)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(232, 72)
        Me.Panel3.TabIndex = 86
        '
        'TextBoxQ3
        '
        Me.TextBoxQ3.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ3.Enabled = False
        Me.TextBoxQ3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ3.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ3.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ3.Name = "TextBoxQ3"
        Me.TextBoxQ3.ReadOnly = True
        Me.TextBoxQ3.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ3.TabIndex = 2
        Me.TextBoxQ3.TabStop = False
        Me.TextBoxQ3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ3Inc
        '
        Me.ButtonQ3Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ3Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ3Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ3Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ3Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ3Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ3Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ3Inc.Name = "ButtonQ3Inc"
        Me.ButtonQ3Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ3Inc.TabIndex = 1
        Me.ButtonQ3Inc.TabStop = False
        Me.ButtonQ3Inc.Text = "+"
        Me.ButtonQ3Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ3Dec
        '
        Me.ButtonQ3Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ3Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ3Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ3Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ3Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ3Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ3Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ3Dec.Name = "ButtonQ3Dec"
        Me.ButtonQ3Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ3Dec.TabIndex = 0
        Me.ButtonQ3Dec.TabStop = False
        Me.ButtonQ3Dec.Text = "-"
        Me.ButtonQ3Dec.UseVisualStyleBackColor = True
        '
        'PriceGreek
        '
        Me.PriceGreek.AutoSize = True
        Me.PriceGreek.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceGreek.ForeColor = System.Drawing.Color.White
        Me.PriceGreek.Location = New System.Drawing.Point(478, 371)
        Me.PriceGreek.Name = "PriceGreek"
        Me.PriceGreek.Size = New System.Drawing.Size(139, 38)
        Me.PriceGreek.TabIndex = 83
        Me.PriceGreek.Text = "0.75 OMR"
        '
        'PriceCaesar
        '
        Me.PriceCaesar.AutoSize = True
        Me.PriceCaesar.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceCaesar.ForeColor = System.Drawing.Color.White
        Me.PriceCaesar.Location = New System.Drawing.Point(128, 371)
        Me.PriceCaesar.Name = "PriceCaesar"
        Me.PriceCaesar.Size = New System.Drawing.Size(139, 38)
        Me.PriceCaesar.TabIndex = 79
        Me.PriceCaesar.Text = "0.75 OMR"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(109, 107)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 76
        Me.PictureBox1.TabStop = False
        '
        'ButtonQ4Inc
        '
        Me.ButtonQ4Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ4Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ4Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ4Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ4Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ4Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ4Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ4Inc.Name = "ButtonQ4Inc"
        Me.ButtonQ4Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ4Inc.TabIndex = 1
        Me.ButtonQ4Inc.TabStop = False
        Me.ButtonQ4Inc.Text = "+"
        Me.ButtonQ4Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ4Dec
        '
        Me.ButtonQ4Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ4Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ4Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ4Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ4Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ4Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ4Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ4Dec.Name = "ButtonQ4Dec"
        Me.ButtonQ4Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ4Dec.TabIndex = 0
        Me.ButtonQ4Dec.TabStop = False
        Me.ButtonQ4Dec.Text = "-"
        Me.ButtonQ4Dec.UseVisualStyleBackColor = True
        '
        'CheckBoxMacchiato
        '
        Me.CheckBoxMacchiato.AutoSize = True
        Me.CheckBoxMacchiato.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxMacchiato.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxMacchiato.ForeColor = System.Drawing.Color.White
        Me.CheckBoxMacchiato.Location = New System.Drawing.Point(452, 322)
        Me.CheckBoxMacchiato.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxMacchiato.Name = "CheckBoxMacchiato"
        Me.CheckBoxMacchiato.Size = New System.Drawing.Size(192, 36)
        Me.CheckBoxMacchiato.TabIndex = 81
        Me.CheckBoxMacchiato.TabStop = False
        Me.CheckBoxMacchiato.Text = "Greek Salad"
        Me.CheckBoxMacchiato.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(457, 107)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 80
        Me.PictureBox2.TabStop = False
        '
        'CheckBoxCaesar
        '
        Me.CheckBoxCaesar.AutoSize = True
        Me.CheckBoxCaesar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxCaesar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxCaesar.ForeColor = System.Drawing.Color.White
        Me.CheckBoxCaesar.Location = New System.Drawing.Point(92, 322)
        Me.CheckBoxCaesar.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxCaesar.Name = "CheckBoxCaesar"
        Me.CheckBoxCaesar.Size = New System.Drawing.Size(206, 36)
        Me.CheckBoxCaesar.TabIndex = 77
        Me.CheckBoxCaesar.TabStop = False
        Me.CheckBoxCaesar.Text = "Caesar Salad"
        Me.CheckBoxCaesar.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(795, 107)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 84
        Me.PictureBox3.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TextBoxQ2)
        Me.Panel2.Controls.Add(Me.ButtonQ2Inc)
        Me.Panel2.Controls.Add(Me.ButtonQ2Dec)
        Me.Panel2.Location = New System.Drawing.Point(431, 434)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(232, 72)
        Me.Panel2.TabIndex = 82
        '
        'TextBoxQ2
        '
        Me.TextBoxQ2.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ2.Enabled = False
        Me.TextBoxQ2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ2.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ2.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ2.Name = "TextBoxQ2"
        Me.TextBoxQ2.ReadOnly = True
        Me.TextBoxQ2.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ2.TabIndex = 2
        Me.TextBoxQ2.TabStop = False
        Me.TextBoxQ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ2Inc
        '
        Me.ButtonQ2Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ2Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ2Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ2Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ2Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ2Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ2Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ2Inc.Name = "ButtonQ2Inc"
        Me.ButtonQ2Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ2Inc.TabIndex = 1
        Me.ButtonQ2Inc.TabStop = False
        Me.ButtonQ2Inc.Text = "+"
        Me.ButtonQ2Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ2Dec
        '
        Me.ButtonQ2Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ2Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ2Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ2Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ2Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ2Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ2Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ2Dec.Name = "ButtonQ2Dec"
        Me.ButtonQ2Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ2Dec.TabIndex = 0
        Me.ButtonQ2Dec.TabStop = False
        Me.ButtonQ2Dec.Text = "-"
        Me.ButtonQ2Dec.UseVisualStyleBackColor = True
        '
        'CheckBoxAmericano
        '
        Me.CheckBoxAmericano.AutoSize = True
        Me.CheckBoxAmericano.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxAmericano.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxAmericano.ForeColor = System.Drawing.Color.White
        Me.CheckBoxAmericano.Location = New System.Drawing.Point(746, 322)
        Me.CheckBoxAmericano.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxAmericano.Name = "CheckBoxAmericano"
        Me.CheckBoxAmericano.Size = New System.Drawing.Size(284, 36)
        Me.CheckBoxAmericano.TabIndex = 85
        Me.CheckBoxAmericano.TabStop = False
        Me.CheckBoxAmericano.Text = "Sweet Potato Salad"
        Me.CheckBoxAmericano.UseVisualStyleBackColor = True
        '
        'TextBoxQ1
        '
        Me.TextBoxQ1.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ1.Enabled = False
        Me.TextBoxQ1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ1.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ1.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ1.Name = "TextBoxQ1"
        Me.TextBoxQ1.ReadOnly = True
        Me.TextBoxQ1.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ1.TabIndex = 2
        Me.TextBoxQ1.TabStop = False
        Me.TextBoxQ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TextBoxQ1)
        Me.Panel1.Controls.Add(Me.ButtonQ1Inc)
        Me.Panel1.Controls.Add(Me.ButtonQ1Dec)
        Me.Panel1.Location = New System.Drawing.Point(83, 434)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(232, 72)
        Me.Panel1.TabIndex = 78
        '
        'ButtonQ1Dec
        '
        Me.ButtonQ1Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ1Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ1Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ1Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ1Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ1Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ1Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ1Dec.Name = "ButtonQ1Dec"
        Me.ButtonQ1Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ1Dec.TabIndex = 0
        Me.ButtonQ1Dec.TabStop = False
        Me.ButtonQ1Dec.Text = "-"
        Me.ButtonQ1Dec.UseVisualStyleBackColor = True
        '
        'ButtonQ6Inc
        '
        Me.ButtonQ6Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ6Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ6Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ6Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ6Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ6Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ6Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ6Inc.Name = "ButtonQ6Inc"
        Me.ButtonQ6Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ6Inc.TabIndex = 1
        Me.ButtonQ6Inc.TabStop = False
        Me.ButtonQ6Inc.Text = "+"
        Me.ButtonQ6Inc.UseVisualStyleBackColor = True
        '
        'CheckBoxAsian
        '
        Me.CheckBoxAsian.AutoSize = True
        Me.CheckBoxAsian.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxAsian.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxAsian.ForeColor = System.Drawing.Color.White
        Me.CheckBoxAsian.Location = New System.Drawing.Point(447, 811)
        Me.CheckBoxAsian.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxAsian.Name = "CheckBoxAsian"
        Me.CheckBoxAsian.Size = New System.Drawing.Size(216, 36)
        Me.CheckBoxAsian.TabIndex = 93
        Me.CheckBoxAsian.TabStop = False
        Me.CheckBoxAsian.Text = "Asian Chicken"
        Me.CheckBoxAsian.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.Location = New System.Drawing.Point(457, 595)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 92
        Me.PictureBox5.TabStop = False
        '
        'PriceCrab
        '
        Me.PriceCrab.AutoSize = True
        Me.PriceCrab.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceCrab.ForeColor = System.Drawing.Color.White
        Me.PriceCrab.Location = New System.Drawing.Point(128, 859)
        Me.PriceCrab.Name = "PriceCrab"
        Me.PriceCrab.Size = New System.Drawing.Size(124, 38)
        Me.PriceCrab.TabIndex = 91
        Me.PriceCrab.Text = "1.5 OMR"
        '
        'CheckBoxCrab
        '
        Me.CheckBoxCrab.AutoSize = True
        Me.CheckBoxCrab.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxCrab.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxCrab.ForeColor = System.Drawing.Color.White
        Me.CheckBoxCrab.Location = New System.Drawing.Point(109, 810)
        Me.CheckBoxCrab.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxCrab.Name = "CheckBoxCrab"
        Me.CheckBoxCrab.Size = New System.Drawing.Size(176, 36)
        Me.CheckBoxCrab.TabIndex = 89
        Me.CheckBoxCrab.TabStop = False
        Me.CheckBoxCrab.Text = "Crab Salad"
        Me.CheckBoxCrab.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Location = New System.Drawing.Point(109, 595)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 88
        Me.PictureBox4.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.TextBoxQ5)
        Me.Panel5.Controls.Add(Me.ButtonQ5Inc)
        Me.Panel5.Controls.Add(Me.ButtonQ5Dec)
        Me.Panel5.Location = New System.Drawing.Point(431, 921)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(232, 72)
        Me.Panel5.TabIndex = 94
        '
        'TextBoxQ5
        '
        Me.TextBoxQ5.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ5.Enabled = False
        Me.TextBoxQ5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ5.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ5.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ5.Name = "TextBoxQ5"
        Me.TextBoxQ5.ReadOnly = True
        Me.TextBoxQ5.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ5.TabIndex = 2
        Me.TextBoxQ5.TabStop = False
        Me.TextBoxQ5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ5Inc
        '
        Me.ButtonQ5Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ5Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ5Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ5Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ5Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ5Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ5Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ5Inc.Name = "ButtonQ5Inc"
        Me.ButtonQ5Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ5Inc.TabIndex = 1
        Me.ButtonQ5Inc.TabStop = False
        Me.ButtonQ5Inc.Text = "+"
        Me.ButtonQ5Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ5Dec
        '
        Me.ButtonQ5Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ5Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ5Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ5Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ5Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ5Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ5Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ5Dec.Name = "ButtonQ5Dec"
        Me.ButtonQ5Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ5Dec.TabIndex = 0
        Me.ButtonQ5Dec.TabStop = False
        Me.ButtonQ5Dec.Text = "-"
        Me.ButtonQ5Dec.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.TextBoxQ4)
        Me.Panel4.Controls.Add(Me.ButtonQ4Inc)
        Me.Panel4.Controls.Add(Me.ButtonQ4Dec)
        Me.Panel4.Location = New System.Drawing.Point(83, 921)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(232, 72)
        Me.Panel4.TabIndex = 90
        '
        'TextBoxQ4
        '
        Me.TextBoxQ4.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ4.Enabled = False
        Me.TextBoxQ4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ4.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ4.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ4.Name = "TextBoxQ4"
        Me.TextBoxQ4.ReadOnly = True
        Me.TextBoxQ4.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ4.TabIndex = 2
        Me.TextBoxQ4.TabStop = False
        Me.TextBoxQ4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PriceAmericano
        '
        Me.PriceAmericano.AutoSize = True
        Me.PriceAmericano.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceAmericano.ForeColor = System.Drawing.Color.White
        Me.PriceAmericano.Location = New System.Drawing.Point(819, 371)
        Me.PriceAmericano.Name = "PriceAmericano"
        Me.PriceAmericano.Size = New System.Drawing.Size(139, 38)
        Me.PriceAmericano.TabIndex = 87
        Me.PriceAmericano.Text = "0.75 OMR"
        '
        'PriceVeggie
        '
        Me.PriceVeggie.AutoSize = True
        Me.PriceVeggie.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceVeggie.ForeColor = System.Drawing.Color.White
        Me.PriceVeggie.Location = New System.Drawing.Point(819, 859)
        Me.PriceVeggie.Name = "PriceVeggie"
        Me.PriceVeggie.Size = New System.Drawing.Size(124, 38)
        Me.PriceVeggie.TabIndex = 99
        Me.PriceVeggie.Text = "0.5 OMR"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.TextBoxQ6)
        Me.Panel6.Controls.Add(Me.ButtonQ6Inc)
        Me.Panel6.Controls.Add(Me.ButtonQ6Dec)
        Me.Panel6.Location = New System.Drawing.Point(771, 921)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(232, 72)
        Me.Panel6.TabIndex = 98
        '
        'ButtonQ6Dec
        '
        Me.ButtonQ6Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ6Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ6Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ6Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ6Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ6Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ6Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ6Dec.Name = "ButtonQ6Dec"
        Me.ButtonQ6Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ6Dec.TabIndex = 0
        Me.ButtonQ6Dec.TabStop = False
        Me.ButtonQ6Dec.Text = "-"
        Me.ButtonQ6Dec.UseVisualStyleBackColor = True
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Salads
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1123, 1101)
        Me.Controls.Add(Me.CheckBoxMocha)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PriceAsian)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.PriceGreek)
        Me.Controls.Add(Me.PriceCaesar)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CheckBoxMacchiato)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.CheckBoxCaesar)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.CheckBoxAmericano)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CheckBoxAsian)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PriceCrab)
        Me.Controls.Add(Me.CheckBoxCrab)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.PriceAmericano)
        Me.Controls.Add(Me.PriceVeggie)
        Me.Controls.Add(Me.Panel6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.Name = "Salads"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Salads"
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxQ6 As TextBox
    Friend WithEvents ButtonQ1Inc As Button
    Friend WithEvents CheckBoxMocha As CheckBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PriceAsian As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBoxQ3 As TextBox
    Friend WithEvents ButtonQ3Inc As Button
    Friend WithEvents ButtonQ3Dec As Button
    Friend WithEvents PriceGreek As Label
    Friend WithEvents PriceCaesar As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ButtonQ4Inc As Button
    Friend WithEvents ButtonQ4Dec As Button
    Friend WithEvents CheckBoxMacchiato As CheckBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents CheckBoxCaesar As CheckBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBoxQ2 As TextBox
    Friend WithEvents ButtonQ2Inc As Button
    Friend WithEvents ButtonQ2Dec As Button
    Friend WithEvents CheckBoxAmericano As CheckBox
    Friend WithEvents TextBoxQ1 As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ButtonQ1Dec As Button
    Friend WithEvents ButtonQ6Inc As Button
    Friend WithEvents CheckBoxAsian As CheckBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PriceCrab As Label
    Friend WithEvents CheckBoxCrab As CheckBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBoxQ5 As TextBox
    Friend WithEvents ButtonQ5Inc As Button
    Friend WithEvents ButtonQ5Dec As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBoxQ4 As TextBox
    Friend WithEvents PriceAmericano As Label
    Friend WithEvents PriceVeggie As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents ButtonQ6Dec As Button
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
End Class
