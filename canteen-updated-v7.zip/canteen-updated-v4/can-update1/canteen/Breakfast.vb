﻿Public Class Breakfast
    Private Sub ButtonQ1Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ1Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceChocoWaffle, TextBoxQ1, CheckBoxChocoWaffle)
    End Sub

    Private Sub ButtonQ1Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ1Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceChocoWaffle, TextBoxQ1, CheckBoxChocoWaffle)
    End Sub

    Private Sub CheckBoxEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxChocoWaffle.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxChocoWaffle, Panel1, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ1, PriceChocoWaffle)
    End Sub



    Private Sub ButtonQ2Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ2Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricePotatoWaffle, TextBoxQ2, CheckBoxPotatoWaffle)
    End Sub

    Private Sub ButtonQ2Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ2Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricePotatoWaffle, TextBoxQ2, CheckBoxPotatoWaffle)
    End Sub

    Private Sub CheckBoxMacchiato_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxPotatoWaffle.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxPotatoWaffle, Panel2, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ2, PricePotatoWaffle)
    End Sub



    Private Sub ButtonQ3Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ3Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricePancake, TextBoxQ3, CheckBoxPancake)
    End Sub

    Private Sub ButtonQ3Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ3Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricePancake, TextBoxQ3, CheckBoxPancake)
    End Sub

    Private Sub CheckBoxAmericano_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxPancake.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxPancake, Panel3, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ3, PricePancake)
    End Sub



    Private Sub ButtonQ4Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ4Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCherryPancake, TextBoxQ4, CheckBoxCherryPancake)
    End Sub

    Private Sub ButtonQ4Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ4Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCherryPancake, TextBoxQ4, CheckBoxCherryPancake)
    End Sub

    Private Sub CheckBoxlatte_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxCherryPancake.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxCherryPancake, Panel4, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ4, PriceCherryPancake)
    End Sub



    Private Sub ButtonQ5Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ5Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceChickenEgg, TextBoxQ5, CheckBoxChickenEgg)
    End Sub

    Private Sub ButtonQ5Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ5Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceChickenEgg, TextBoxQ5, CheckBoxChickenEgg)
    End Sub

    Private Sub CheckBoxCappuccino_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxChickenEgg.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxChickenEgg, Panel5, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ5, PriceChickenEgg)
    End Sub



    Private Sub ButtonQ6Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ6Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceSausageEgg, TextBoxQ6, CheckBoxSausageEgg)
    End Sub

    Private Sub ButtonQ6Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ6Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceSausageEgg, TextBoxQ6, CheckBoxSausageEgg)
    End Sub

    Private Sub CheckBoxMocha_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxSausageEgg.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxSausageEgg, Panel6, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ6, PriceSausageEgg)
    End Sub



    Private Sub HotCoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CanteenDashboard.QuantityVisibility(TextBoxQ1, Panel1)
        CanteenDashboard.QuantityVisibility(TextBoxQ2, Panel2)
        CanteenDashboard.QuantityVisibility(TextBoxQ3, Panel3)
        CanteenDashboard.QuantityVisibility(TextBoxQ4, Panel4)
        CanteenDashboard.QuantityVisibility(TextBoxQ5, Panel5)
        CanteenDashboard.QuantityVisibility(TextBoxQ6, Panel6)
    End Sub



    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub
End Class