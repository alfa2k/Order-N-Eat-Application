﻿Public Class BitAndBites
    Private Sub ButtonQ1Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ1Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCheeseFries, TextBoxQ1, CheckBoxCheeseFries)
    End Sub

    Private Sub ButtonQ1Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ1Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCheeseFries, TextBoxQ1, CheckBoxCheeseFries)
    End Sub

    Private Sub CheckBoxEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxCheeseFries.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxCheeseFries, Panel1, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ1, PriceCheeseFries)
    End Sub



    Private Sub ButtonQ2Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ2Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceWings, TextBoxQ2, CheckBoxWings)
    End Sub

    Private Sub ButtonQ2Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ2Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceWings, TextBoxQ2, CheckBoxWings)
    End Sub

    Private Sub CheckBoxMacchiato_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxWings.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxWings, Panel2, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ2, PriceWings)
    End Sub



    Private Sub ButtonQ3Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ3Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricelLoaded, TextBoxQ3, CheckBoxLoaded)
    End Sub

    Private Sub ButtonQ3Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ3Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricelLoaded, TextBoxQ3, CheckBoxLoaded)
    End Sub

    Private Sub CheckBoxAmericano_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxLoaded.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxLoaded, Panel3, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ3, PricelLoaded)
    End Sub



    Private Sub ButtonQ4Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ4Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceFries, TextBoxQ4, CheckBoxFries)
    End Sub

    Private Sub ButtonQ4Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ4Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceFries, TextBoxQ4, CheckBoxFries)
    End Sub

    Private Sub CheckBoxlatte_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxFries.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxFries, Panel4, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ4, PriceFries)
    End Sub



    Private Sub ButtonQ5Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ5Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceNuggets, TextBoxQ5, CheckBoxNuggets)
    End Sub

    Private Sub ButtonQ5Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ5Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceNuggets, TextBoxQ5, CheckBoxNuggets)
    End Sub

    Private Sub CheckBoxCappuccino_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxNuggets.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxNuggets, Panel5, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ5, PriceNuggets)
    End Sub



    Private Sub ButtonQ6Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ6Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricePotato, TextBoxQ6, CheckBoxPotato)
    End Sub

    Private Sub ButtonQ6Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ6Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PricePotato, TextBoxQ6, CheckBoxPotato)
    End Sub

    Private Sub CheckBoxMocha_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxPotato.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxPotato, Panel6, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ6, PricePotato)
    End Sub



    Private Sub HotCoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CanteenDashboard.QuantityVisibility(TextBoxQ1, Panel1)
        CanteenDashboard.QuantityVisibility(TextBoxQ2, Panel2)
        CanteenDashboard.QuantityVisibility(TextBoxQ3, Panel3)
        CanteenDashboard.QuantityVisibility(TextBoxQ4, Panel4)
        CanteenDashboard.QuantityVisibility(TextBoxQ5, Panel5)
        CanteenDashboard.QuantityVisibility(TextBoxQ6, Panel6)
    End Sub



    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub
End Class