﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OrderFood
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OrderFood))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnClose = New Guna.UI2.WinForms.Guna2Button()
        Me.ButtonSoups = New System.Windows.Forms.Button()
        Me.ButtonBits = New System.Windows.Forms.Button()
        Me.ButtonSalads = New System.Windows.Forms.Button()
        Me.ButtonBreakfast = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PanelChildForm = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ListBoxItems = New System.Windows.Forms.ListBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBoxTotal = New System.Windows.Forms.TextBox()
        Me.LabelTotal = New System.Windows.Forms.Label()
        Me.ButtonCheckout = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.LabelYourCart = New System.Windows.Forms.Label()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel1.Controls.Add(Me.BtnClose)
        Me.Panel1.Controls.Add(Me.ButtonSoups)
        Me.Panel1.Controls.Add(Me.ButtonBits)
        Me.Panel1.Controls.Add(Me.ButtonSalads)
        Me.Panel1.Controls.Add(Me.ButtonBreakfast)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(300, 1099)
        Me.Panel1.TabIndex = 0
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.BtnClose.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnClose.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnClose.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnClose.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.BtnClose.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BtnClose.ForeColor = System.Drawing.Color.White
        Me.BtnClose.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.BtnClose.Location = New System.Drawing.Point(0, 637)
        Me.BtnClose.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(300, 64)
        Me.BtnClose.TabIndex = 13
        Me.BtnClose.Text = "Return Back"
        '
        'ButtonSoups
        '
        Me.ButtonSoups.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonSoups.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonSoups.FlatAppearance.BorderSize = 0
        Me.ButtonSoups.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.ButtonSoups.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSoups.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonSoups.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonSoups.Location = New System.Drawing.Point(0, 517)
        Me.ButtonSoups.Margin = New System.Windows.Forms.Padding(5)
        Me.ButtonSoups.Name = "ButtonSoups"
        Me.ButtonSoups.Size = New System.Drawing.Size(300, 120)
        Me.ButtonSoups.TabIndex = 3
        Me.ButtonSoups.Text = "Soups"
        Me.ButtonSoups.UseVisualStyleBackColor = False
        '
        'ButtonBits
        '
        Me.ButtonBits.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonBits.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonBits.FlatAppearance.BorderSize = 0
        Me.ButtonBits.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.ButtonBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonBits.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonBits.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonBits.Location = New System.Drawing.Point(0, 397)
        Me.ButtonBits.Margin = New System.Windows.Forms.Padding(5)
        Me.ButtonBits.Name = "ButtonBits"
        Me.ButtonBits.Size = New System.Drawing.Size(300, 120)
        Me.ButtonBits.TabIndex = 2
        Me.ButtonBits.Text = "Bits And Bites"
        Me.ButtonBits.UseVisualStyleBackColor = False
        '
        'ButtonSalads
        '
        Me.ButtonSalads.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonSalads.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonSalads.FlatAppearance.BorderSize = 0
        Me.ButtonSalads.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.ButtonSalads.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSalads.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonSalads.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonSalads.Location = New System.Drawing.Point(0, 277)
        Me.ButtonSalads.Margin = New System.Windows.Forms.Padding(5)
        Me.ButtonSalads.Name = "ButtonSalads"
        Me.ButtonSalads.Size = New System.Drawing.Size(300, 120)
        Me.ButtonSalads.TabIndex = 1
        Me.ButtonSalads.Text = "Salads"
        Me.ButtonSalads.UseVisualStyleBackColor = False
        '
        'ButtonBreakfast
        '
        Me.ButtonBreakfast.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonBreakfast.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonBreakfast.FlatAppearance.BorderSize = 0
        Me.ButtonBreakfast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.ButtonBreakfast.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonBreakfast.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonBreakfast.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonBreakfast.Location = New System.Drawing.Point(0, 157)
        Me.ButtonBreakfast.Margin = New System.Windows.Forms.Padding(5)
        Me.ButtonBreakfast.Name = "ButtonBreakfast"
        Me.ButtonBreakfast.Size = New System.Drawing.Size(300, 120)
        Me.ButtonBreakfast.TabIndex = 0
        Me.ButtonBreakfast.Text = "Breakfast"
        Me.ButtonBreakfast.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Image = Global.canteen.My.Resources.Resources.My_project1
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(300, 157)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PanelChildForm
        '
        Me.PanelChildForm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelChildForm.Location = New System.Drawing.Point(300, 0)
        Me.PanelChildForm.Margin = New System.Windows.Forms.Padding(5)
        Me.PanelChildForm.Name = "PanelChildForm"
        Me.PanelChildForm.Size = New System.Drawing.Size(1122, 1099)
        Me.PanelChildForm.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.ListBoxItems)
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Controls.Add(Me.ButtonCheckout)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(1422, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(411, 1099)
        Me.Panel3.TabIndex = 0
        '
        'ListBoxItems
        '
        Me.ListBoxItems.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ListBoxItems.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBoxItems.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBoxItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ListBoxItems.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ListBoxItems.FormattingEnabled = True
        Me.ListBoxItems.ItemHeight = 26
        Me.ListBoxItems.Items.AddRange(New Object() {" "})
        Me.ListBoxItems.Location = New System.Drawing.Point(0, 144)
        Me.ListBoxItems.Margin = New System.Windows.Forms.Padding(5)
        Me.ListBoxItems.Name = "ListBoxItems"
        Me.ListBoxItems.Size = New System.Drawing.Size(411, 704)
        Me.ListBoxItems.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Panel5.Controls.Add(Me.TextBoxTotal)
        Me.Panel5.Controls.Add(Me.LabelTotal)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(0, 848)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(411, 141)
        Me.Panel5.TabIndex = 3
        '
        'TextBoxTotal
        '
        Me.TextBoxTotal.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.TextBoxTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.TextBoxTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxTotal.Enabled = False
        Me.TextBoxTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxTotal.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBoxTotal.Location = New System.Drawing.Point(243, 52)
        Me.TextBoxTotal.Margin = New System.Windows.Forms.Padding(5)
        Me.TextBoxTotal.Name = "TextBoxTotal"
        Me.TextBoxTotal.ReadOnly = True
        Me.TextBoxTotal.Size = New System.Drawing.Size(150, 26)
        Me.TextBoxTotal.TabIndex = 4
        '
        'LabelTotal
        '
        Me.LabelTotal.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.LabelTotal.AutoSize = True
        Me.LabelTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LabelTotal.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.LabelTotal.Location = New System.Drawing.Point(19, 52)
        Me.LabelTotal.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.LabelTotal.Name = "LabelTotal"
        Me.LabelTotal.Size = New System.Drawing.Size(73, 29)
        Me.LabelTotal.TabIndex = 3
        Me.LabelTotal.Text = "Total"
        '
        'ButtonCheckout
        '
        Me.ButtonCheckout.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonCheckout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ButtonCheckout.FlatAppearance.BorderSize = 0
        Me.ButtonCheckout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonCheckout.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonCheckout.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonCheckout.Location = New System.Drawing.Point(0, 989)
        Me.ButtonCheckout.Margin = New System.Windows.Forms.Padding(5)
        Me.ButtonCheckout.Name = "ButtonCheckout"
        Me.ButtonCheckout.Size = New System.Drawing.Size(411, 110)
        Me.ButtonCheckout.TabIndex = 2
        Me.ButtonCheckout.Text = "Proceed to checkout"
        Me.ButtonCheckout.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Panel4.Controls.Add(Me.LabelYourCart)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(411, 144)
        Me.Panel4.TabIndex = 1
        '
        'LabelYourCart
        '
        Me.LabelYourCart.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LabelYourCart.AutoSize = True
        Me.LabelYourCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LabelYourCart.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelYourCart.Location = New System.Drawing.Point(134, 52)
        Me.LabelYourCart.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.LabelYourCart.Name = "LabelYourCart"
        Me.LabelYourCart.Size = New System.Drawing.Size(134, 32)
        Me.LabelYourCart.TabIndex = 0
        Me.LabelYourCart.Text = "Your Cart"
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'OrderFood
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1833, 1099)
        Me.Controls.Add(Me.PanelChildForm)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.MinimumSize = New System.Drawing.Size(1589, 807)
        Me.Name = "OrderFood"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Order Food"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents ButtonSoups As Button
    Friend WithEvents ButtonBits As Button
    Friend WithEvents ButtonSalads As Button
    Friend WithEvents ButtonBreakfast As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PanelChildForm As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBoxTotal As TextBox
    Friend WithEvents LabelTotal As Label
    Friend WithEvents ButtonCheckout As Button
    Friend WithEvents ListBoxItems As ListBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents LabelYourCart As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents BtnClose As Guna.UI2.WinForms.Guna2Button
End Class
