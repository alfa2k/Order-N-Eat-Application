﻿CREATE TABLE [dbo].[OrderTable] (
    [OrderID]     INT        IDENTITY (1, 1) NOT NULL,
    [OrderDate]   DATETIME       NOT NULL,
    [OrderAmount] FLOAT (53) NOT NULL,
    PRIMARY KEY CLUSTERED ([OrderID] ASC)
);

