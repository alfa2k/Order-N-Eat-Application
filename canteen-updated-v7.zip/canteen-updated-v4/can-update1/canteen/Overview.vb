﻿Imports System.Data.SqlClient
Public Class Overview
    Dim con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v4\can-update1\canteen\Management1.mdf;Integrated Security=True")

    Private Sub displaySalesTable()
        con.open()
        Dim query = "select * from SalesTable"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        gridSales.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub displayItemsTable()
        con.open()
        Dim query = "select * from ItemTable"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        gridItems.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub displayOrderTable()
        con.open()
        Dim query = "select * from OrderTable"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        gridOrders.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub Overview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        displaySalesTable()
        displayItemsTable()
        displayOrderTable()
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        displaySalesTable()
        displayItemsTable()
        displayOrderTable()
    End Sub
End Class