﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LoginPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2ControlBox3 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2ControlBox1 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RadioButtonStudent = New Guna.UI2.WinForms.Guna2RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RadioButtonStaff = New Guna.UI2.WinForms.Guna2RadioButton()
        Me.LabelUsername = New System.Windows.Forms.Label()
        Me.TextBoxUserName = New System.Windows.Forms.TextBox()
        Me.TextBoxPassword = New System.Windows.Forms.TextBox()
        Me.LabelPassword = New System.Windows.Forms.Label()
        Me.LoginSubmitButton = New Guna.UI2.WinForms.Guna2Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnCreateAccount = New Guna.UI2.WinForms.Guna2Button()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox1.Image = Global.canteen.My.Resources.Resources.imageedit_5_4705985991
        Me.Guna2PictureBox1.ImageRotate = 0!
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(10, 9)
        Me.Guna2PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(563, 482)
        Me.Guna2PictureBox1.TabIndex = 0
        Me.Guna2PictureBox1.TabStop = False
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.Controls.Add(Me.Guna2ControlBox3)
        Me.Guna2Panel3.Controls.Add(Me.Guna2ControlBox1)
        Me.Guna2Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.Size = New System.Drawing.Size(1144, 26)
        Me.Guna2Panel3.TabIndex = 0
        '
        'Guna2ControlBox3
        '
        Me.Guna2ControlBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox
        Me.Guna2ControlBox3.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2ControlBox3.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox3.Location = New System.Drawing.Point(1041, 0)
        Me.Guna2ControlBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2ControlBox3.Name = "Guna2ControlBox3"
        Me.Guna2ControlBox3.Size = New System.Drawing.Size(56, 27)
        Me.Guna2ControlBox3.TabIndex = 1
        '
        'Guna2ControlBox1
        '
        Me.Guna2ControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox1.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2ControlBox1.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox1.Location = New System.Drawing.Point(1096, 0)
        Me.Guna2ControlBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2ControlBox1.Name = "Guna2ControlBox1"
        Me.Guna2ControlBox1.Size = New System.Drawing.Size(49, 27)
        Me.Guna2ControlBox1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(806, 82)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 30)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Are You a - "
        '
        'RadioButtonStudent
        '
        Me.RadioButtonStudent.Animated = True
        Me.RadioButtonStudent.AutoSize = True
        Me.RadioButtonStudent.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.RadioButtonStudent.CheckedState.BorderThickness = 0
        Me.RadioButtonStudent.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.RadioButtonStudent.CheckedState.InnerColor = System.Drawing.Color.White
        Me.RadioButtonStudent.CheckedState.InnerOffset = -4
        Me.RadioButtonStudent.Font = New System.Drawing.Font("Segoe UI", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.RadioButtonStudent.ForeColor = System.Drawing.SystemColors.Control
        Me.RadioButtonStudent.Location = New System.Drawing.Point(806, 135)
        Me.RadioButtonStudent.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.RadioButtonStudent.Name = "RadioButtonStudent"
        Me.RadioButtonStudent.Size = New System.Drawing.Size(97, 29)
        Me.RadioButtonStudent.TabIndex = 2
        Me.RadioButtonStudent.Text = "Student"
        Me.RadioButtonStudent.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.RadioButtonStudent.UncheckedState.BorderThickness = 2
        Me.RadioButtonStudent.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.RadioButtonStudent.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(921, 135)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "or"
        '
        'RadioButtonStaff
        '
        Me.RadioButtonStaff.Animated = True
        Me.RadioButtonStaff.AutoSize = True
        Me.RadioButtonStaff.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.RadioButtonStaff.CheckedState.BorderThickness = 0
        Me.RadioButtonStaff.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.RadioButtonStaff.CheckedState.InnerColor = System.Drawing.Color.White
        Me.RadioButtonStaff.CheckedState.InnerOffset = -4
        Me.RadioButtonStaff.Font = New System.Drawing.Font("Segoe UI", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.RadioButtonStaff.ForeColor = System.Drawing.SystemColors.Control
        Me.RadioButtonStaff.Location = New System.Drawing.Point(976, 135)
        Me.RadioButtonStaff.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.RadioButtonStaff.Name = "RadioButtonStaff"
        Me.RadioButtonStaff.Size = New System.Drawing.Size(72, 29)
        Me.RadioButtonStaff.TabIndex = 4
        Me.RadioButtonStaff.Text = "Staff"
        Me.RadioButtonStaff.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.RadioButtonStaff.UncheckedState.BorderThickness = 2
        Me.RadioButtonStaff.UncheckedState.FillColor = System.Drawing.Color.Transparent
        Me.RadioButtonStaff.UncheckedState.InnerColor = System.Drawing.Color.Transparent
        '
        'LabelUsername
        '
        Me.LabelUsername.AutoSize = True
        Me.LabelUsername.Font = New System.Drawing.Font("Segoe UI Semibold", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.LabelUsername.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelUsername.Location = New System.Drawing.Point(806, 186)
        Me.LabelUsername.Name = "LabelUsername"
        Me.LabelUsername.Size = New System.Drawing.Size(154, 25)
        Me.LabelUsername.TabIndex = 5
        Me.LabelUsername.Text = "Enter Username:"
        '
        'TextBoxUserName
        '
        Me.TextBoxUserName.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.TextBoxUserName.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxUserName.Location = New System.Drawing.Point(806, 230)
        Me.TextBoxUserName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxUserName.Name = "TextBoxUserName"
        Me.TextBoxUserName.PlaceholderText = "Enter your Academic ID"
        Me.TextBoxUserName.Size = New System.Drawing.Size(249, 29)
        Me.TextBoxUserName.TabIndex = 6
        '
        'TextBoxPassword
        '
        Me.TextBoxPassword.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.TextBoxPassword.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxPassword.Location = New System.Drawing.Point(806, 321)
        Me.TextBoxPassword.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxPassword.Name = "TextBoxPassword"
        Me.TextBoxPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9679)
        Me.TextBoxPassword.PlaceholderText = "Enter your password"
        Me.TextBoxPassword.Size = New System.Drawing.Size(249, 29)
        Me.TextBoxPassword.TabIndex = 8
        '
        'LabelPassword
        '
        Me.LabelPassword.AutoSize = True
        Me.LabelPassword.Font = New System.Drawing.Font("Segoe UI Semibold", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.LabelPassword.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelPassword.Location = New System.Drawing.Point(806, 278)
        Me.LabelPassword.Name = "LabelPassword"
        Me.LabelPassword.Size = New System.Drawing.Size(148, 25)
        Me.LabelPassword.TabIndex = 7
        Me.LabelPassword.Text = "Enter Password:"
        '
        'LoginSubmitButton
        '
        Me.LoginSubmitButton.BorderRadius = 15
        Me.LoginSubmitButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.LoginSubmitButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.LoginSubmitButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.LoginSubmitButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.LoginSubmitButton.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LoginSubmitButton.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LoginSubmitButton.ForeColor = System.Drawing.Color.White
        Me.LoginSubmitButton.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.LoginSubmitButton.Location = New System.Drawing.Point(806, 374)
        Me.LoginSubmitButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.LoginSubmitButton.Name = "LoginSubmitButton"
        Me.LoginSubmitButton.Size = New System.Drawing.Size(248, 42)
        Me.LoginSubmitButton.TabIndex = 9
        Me.LoginSubmitButton.Text = "Submit"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 100.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(669, 44)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(111, 177)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "I"
        '
        'btnCreateAccount
        '
        Me.btnCreateAccount.BorderRadius = 15
        Me.btnCreateAccount.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnCreateAccount.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnCreateAccount.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnCreateAccount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnCreateAccount.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnCreateAccount.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnCreateAccount.ForeColor = System.Drawing.Color.White
        Me.btnCreateAccount.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.btnCreateAccount.Location = New System.Drawing.Point(806, 433)
        Me.btnCreateAccount.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCreateAccount.Name = "btnCreateAccount"
        Me.btnCreateAccount.Size = New System.Drawing.Size(248, 42)
        Me.btnCreateAccount.TabIndex = 11
        Me.btnCreateAccount.Text = "Create Account"
        Me.btnCreateAccount.Visible = False
        '
        'LoginPage
        '
        Me.AcceptButton = Me.LoginSubmitButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1144, 500)
        Me.Controls.Add(Me.btnCreateAccount)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LoginSubmitButton)
        Me.Controls.Add(Me.TextBoxPassword)
        Me.Controls.Add(Me.LabelPassword)
        Me.Controls.Add(Me.TextBoxUserName)
        Me.Controls.Add(Me.LabelUsername)
        Me.Controls.Add(Me.RadioButtonStaff)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RadioButtonStudent)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Guna2Panel3)
        Me.Controls.Add(Me.Guna2PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "LoginPage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login Page"
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2ControlBox3 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2ControlBox1 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents LoginSubmitButton As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents TextBoxPassword As TextBox
    Friend WithEvents LabelPassword As Label
    Friend WithEvents TextBoxUserName As TextBox
    Friend WithEvents LabelUsername As Label
    Friend WithEvents RadioButtonStaff As Guna.UI2.WinForms.Guna2RadioButton
    Friend WithEvents Label2 As Label
    Friend WithEvents RadioButtonStudent As Guna.UI2.WinForms.Guna2RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btnCreateAccount As Guna.UI2.WinForms.Guna2Button
End Class
