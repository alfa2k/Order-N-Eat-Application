﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FoodCheckout
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ComboBoxVISA = New System.Windows.Forms.ComboBox()
        Me.RadioButtonCash = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButtonVISA = New System.Windows.Forms.RadioButton()
        Me.TextBoxVISA = New System.Windows.Forms.TextBox()
        Me.LabelVisa = New System.Windows.Forms.Label()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.BtnOrder = New Guna.UI2.WinForms.Guna2Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBoxVISA
        '
        Me.ComboBoxVISA.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ComboBoxVISA.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.ComboBoxVISA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxVISA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBoxVISA.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ComboBoxVISA.FormattingEnabled = True
        Me.ComboBoxVISA.Items.AddRange(New Object() {"On Pickup", "Online"})
        Me.ComboBoxVISA.Location = New System.Drawing.Point(274, 340)
        Me.ComboBoxVISA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ComboBoxVISA.Name = "ComboBoxVISA"
        Me.ComboBoxVISA.Size = New System.Drawing.Size(289, 33)
        Me.ComboBoxVISA.TabIndex = 0
        '
        'RadioButtonCash
        '
        Me.RadioButtonCash.AutoSize = True
        Me.RadioButtonCash.Location = New System.Drawing.Point(7, 69)
        Me.RadioButtonCash.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.RadioButtonCash.Name = "RadioButtonCash"
        Me.RadioButtonCash.Size = New System.Drawing.Size(185, 29)
        Me.RadioButtonCash.TabIndex = 1
        Me.RadioButtonCash.TabStop = True
        Me.RadioButtonCash.Text = "Cash On Pickup"
        Me.RadioButtonCash.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox1.Controls.Add(Me.RadioButtonVISA)
        Me.GroupBox1.Controls.Add(Me.RadioButtonCash)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.04478!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.GroupBox1.Location = New System.Drawing.Point(274, 140)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(289, 181)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Choose Payment Method"
        '
        'RadioButtonVISA
        '
        Me.RadioButtonVISA.AutoSize = True
        Me.RadioButtonVISA.Location = New System.Drawing.Point(7, 141)
        Me.RadioButtonVISA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.RadioButtonVISA.Name = "RadioButtonVISA"
        Me.RadioButtonVISA.Size = New System.Drawing.Size(77, 29)
        Me.RadioButtonVISA.TabIndex = 2
        Me.RadioButtonVISA.TabStop = True
        Me.RadioButtonVISA.Text = "VISA"
        Me.RadioButtonVISA.UseVisualStyleBackColor = True
        '
        'TextBoxVISA
        '
        Me.TextBoxVISA.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBoxVISA.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(207, Byte), Integer))
        Me.TextBoxVISA.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxVISA.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxVISA.Location = New System.Drawing.Point(274, 448)
        Me.TextBoxVISA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxVISA.Name = "TextBoxVISA"
        Me.TextBoxVISA.Size = New System.Drawing.Size(289, 23)
        Me.TextBoxVISA.TabIndex = 4
        '
        'LabelVisa
        '
        Me.LabelVisa.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LabelVisa.AutoSize = True
        Me.LabelVisa.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LabelVisa.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.LabelVisa.Location = New System.Drawing.Point(275, 416)
        Me.LabelVisa.Name = "LabelVisa"
        Me.LabelVisa.Size = New System.Drawing.Size(180, 25)
        Me.LabelVisa.TabIndex = 5
        Me.LabelVisa.Text = "Enter Card Number"
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'BtnOrder
        '
        Me.BtnOrder.BorderRadius = 15
        Me.BtnOrder.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnOrder.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnOrder.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnOrder.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnOrder.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.BtnOrder.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BtnOrder.ForeColor = System.Drawing.Color.White
        Me.BtnOrder.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.BtnOrder.Location = New System.Drawing.Point(274, 541)
        Me.BtnOrder.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.BtnOrder.Name = "BtnOrder"
        Me.BtnOrder.Size = New System.Drawing.Size(289, 42)
        Me.BtnOrder.TabIndex = 11
        Me.BtnOrder.Text = "Place Order"
        '
        'FoodCheckout
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(873, 717)
        Me.Controls.Add(Me.BtnOrder)
        Me.Controls.Add(Me.LabelVisa)
        Me.Controls.Add(Me.TextBoxVISA)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ComboBoxVISA)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "FoodCheckout"
        Me.Text = "Form6"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ComboBoxVISA As ComboBox
    Friend WithEvents RadioButtonCash As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButtonVISA As RadioButton
    Friend WithEvents TextBoxVISA As TextBox
    Friend WithEvents LabelVisa As Label
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents BtnOrder As Guna.UI2.WinForms.Guna2Button
End Class
