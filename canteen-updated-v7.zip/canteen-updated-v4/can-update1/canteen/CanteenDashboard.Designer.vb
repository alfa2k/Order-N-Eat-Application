﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CanteenDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2ControlBox2 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2ControlBox1 = New Guna.UI2.WinForms.Guna2ControlBox()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.studentBanner = New Guna.UI2.WinForms.Guna2Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.BannerName = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnNotification = New Guna.UI2.WinForms.Guna2Button()
        Me.btnReportPage = New Guna.UI2.WinForms.Guna2Button()
        Me.btnManageSales = New Guna.UI2.WinForms.Guna2Button()
        Me.btnInventory = New Guna.UI2.WinForms.Guna2Button()
        Me.BtnManageOrders = New Guna.UI2.WinForms.Guna2Button()
        Me.btnSignout = New Guna.UI2.WinForms.Guna2Button()
        Me.lblMenu = New System.Windows.Forms.Label()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2DragControl1 = New Guna.UI2.WinForms.Guna2DragControl(Me.components)
        Me.Guna2NotificationPaint1 = New Guna.UI2.WinForms.Guna2NotificationPaint(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBoxOrderNow = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnOrderFood = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2Panel4 = New Guna.UI2.WinForms.Guna2Panel()
        Me.PictureBoxDrinks = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnOrderDrinks = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2PictureBox3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.TimerToday = New System.Windows.Forms.Timer(Me.components)
        Me.Guna2Panel1.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        Me.studentBanner.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PictureBoxOrderNow.SuspendLayout()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel4.SuspendLayout()
        Me.PictureBoxDrinks.SuspendLayout()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Controls.Add(Me.Guna2ControlBox2)
        Me.Guna2Panel1.Controls.Add(Me.Guna2ControlBox1)
        Me.Guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.Size = New System.Drawing.Size(1130, 26)
        Me.Guna2Panel1.TabIndex = 0
        '
        'Guna2ControlBox2
        '
        Me.Guna2ControlBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox2.Animated = True
        Me.Guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox
        Me.Guna2ControlBox2.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Guna2ControlBox2.HoverState.FillColor = System.Drawing.Color.Gray
        Me.Guna2ControlBox2.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox2.Location = New System.Drawing.Point(1030, 0)
        Me.Guna2ControlBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2ControlBox2.Name = "Guna2ControlBox2"
        Me.Guna2ControlBox2.Size = New System.Drawing.Size(49, 27)
        Me.Guna2ControlBox2.TabIndex = 3
        '
        'Guna2ControlBox1
        '
        Me.Guna2ControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2ControlBox1.Animated = True
        Me.Guna2ControlBox1.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.Guna2ControlBox1.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2ControlBox1.IconColor = System.Drawing.Color.White
        Me.Guna2ControlBox1.Location = New System.Drawing.Point(1079, 0)
        Me.Guna2ControlBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2ControlBox1.Name = "Guna2ControlBox1"
        Me.Guna2ControlBox1.Size = New System.Drawing.Size(49, 27)
        Me.Guna2ControlBox1.TabIndex = 2
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2Panel2.Controls.Add(Me.studentBanner)
        Me.Guna2Panel2.Controls.Add(Me.btnNotification)
        Me.Guna2Panel2.Controls.Add(Me.btnReportPage)
        Me.Guna2Panel2.Controls.Add(Me.btnManageSales)
        Me.Guna2Panel2.Controls.Add(Me.btnInventory)
        Me.Guna2Panel2.Controls.Add(Me.BtnManageOrders)
        Me.Guna2Panel2.Controls.Add(Me.btnSignout)
        Me.Guna2Panel2.Controls.Add(Me.lblMenu)
        Me.Guna2Panel2.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Guna2Panel2.Location = New System.Drawing.Point(0, 26)
        Me.Guna2Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.Size = New System.Drawing.Size(245, 488)
        Me.Guna2Panel2.TabIndex = 1
        '
        'studentBanner
        '
        Me.studentBanner.BackColor = System.Drawing.Color.Transparent
        Me.studentBanner.BorderColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.studentBanner.BorderRadius = 18
        Me.studentBanner.Controls.Add(Me.Label4)
        Me.studentBanner.Controls.Add(Me.Label1)
        Me.studentBanner.Controls.Add(Me.lblTime)
        Me.studentBanner.Controls.Add(Me.BannerName)
        Me.studentBanner.Controls.Add(Me.PictureBox1)
        Me.studentBanner.FillColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.studentBanner.Location = New System.Drawing.Point(24, 105)
        Me.studentBanner.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.studentBanner.Name = "studentBanner"
        Me.studentBanner.Size = New System.Drawing.Size(200, 309)
        Me.studentBanner.TabIndex = 6
        Me.studentBanner.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label4.Location = New System.Drawing.Point(11, 182)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(27, 20)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "---"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(11, 227)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 20)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Logged In At - "
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.BackColor = System.Drawing.Color.Transparent
        Me.lblTime.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblTime.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.lblTime.Location = New System.Drawing.Point(11, 260)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(27, 20)
        Me.lblTime.TabIndex = 4
        Me.lblTime.Text = "---"
        '
        'BannerName
        '
        Me.BannerName.AutoSize = True
        Me.BannerName.BackColor = System.Drawing.Color.Transparent
        Me.BannerName.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BannerName.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BannerName.Location = New System.Drawing.Point(11, 151)
        Me.BannerName.Name = "BannerName"
        Me.BannerName.Size = New System.Drawing.Size(74, 20)
        Me.BannerName.TabIndex = 3
        Me.BannerName.Text = "Welcome"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Location = New System.Drawing.Point(18, 17)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(164, 112)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnNotification
        '
        Me.btnNotification.Animated = True
        Me.btnNotification.BorderRadius = 10
        Me.btnNotification.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnNotification.CustomImages.Image = Global.canteen.My.Resources.Resources.icons8_notification_961
        Me.btnNotification.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnNotification.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnNotification.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnNotification.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnNotification.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnNotification.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnNotification.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnNotification.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnNotification.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.btnNotification.HoverState.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnNotification.HoverState.ForeColor = System.Drawing.Color.White
        Me.btnNotification.Location = New System.Drawing.Point(35, 349)
        Me.btnNotification.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNotification.Name = "btnNotification"
        Me.btnNotification.Size = New System.Drawing.Size(171, 35)
        Me.btnNotification.TabIndex = 7
        Me.btnNotification.Text = "Notifications"
        Me.btnNotification.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnNotification.TextOffset = New System.Drawing.Point(35, 0)
        '
        'btnReportPage
        '
        Me.btnReportPage.Animated = True
        Me.btnReportPage.BorderRadius = 10
        Me.btnReportPage.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnReportPage.CustomImages.Image = Global.canteen.My.Resources.Resources.icons8_report_64
        Me.btnReportPage.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnReportPage.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnReportPage.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnReportPage.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnReportPage.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnReportPage.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnReportPage.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnReportPage.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnReportPage.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.btnReportPage.HoverState.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnReportPage.HoverState.ForeColor = System.Drawing.Color.White
        Me.btnReportPage.Location = New System.Drawing.Point(35, 295)
        Me.btnReportPage.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnReportPage.Name = "btnReportPage"
        Me.btnReportPage.Size = New System.Drawing.Size(171, 35)
        Me.btnReportPage.TabIndex = 6
        Me.btnReportPage.Text = "Report Page"
        Me.btnReportPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnReportPage.TextOffset = New System.Drawing.Point(35, 0)
        '
        'btnManageSales
        '
        Me.btnManageSales.Animated = True
        Me.btnManageSales.BorderRadius = 10
        Me.btnManageSales.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnManageSales.CustomImages.Image = Global.canteen.My.Resources.Resources.icons8_sales_64
        Me.btnManageSales.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnManageSales.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnManageSales.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnManageSales.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnManageSales.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnManageSales.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnManageSales.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnManageSales.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnManageSales.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.btnManageSales.HoverState.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnManageSales.HoverState.ForeColor = System.Drawing.Color.White
        Me.btnManageSales.Location = New System.Drawing.Point(35, 239)
        Me.btnManageSales.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnManageSales.Name = "btnManageSales"
        Me.btnManageSales.Size = New System.Drawing.Size(171, 35)
        Me.btnManageSales.TabIndex = 5
        Me.btnManageSales.Text = "Manage Sales"
        Me.btnManageSales.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnManageSales.TextOffset = New System.Drawing.Point(35, 0)
        '
        'btnInventory
        '
        Me.btnInventory.Animated = True
        Me.btnInventory.BorderRadius = 10
        Me.btnInventory.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnInventory.CustomImages.Image = Global.canteen.My.Resources.Resources.icons8_inventory_641
        Me.btnInventory.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnInventory.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnInventory.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnInventory.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnInventory.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnInventory.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnInventory.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnInventory.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnInventory.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.btnInventory.HoverState.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnInventory.HoverState.ForeColor = System.Drawing.Color.White
        Me.btnInventory.Location = New System.Drawing.Point(35, 184)
        Me.btnInventory.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnInventory.Name = "btnInventory"
        Me.btnInventory.Size = New System.Drawing.Size(171, 35)
        Me.btnInventory.TabIndex = 4
        Me.btnInventory.Text = "Inventory "
        Me.btnInventory.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnInventory.TextOffset = New System.Drawing.Point(35, 0)
        '
        'BtnManageOrders
        '
        Me.BtnManageOrders.Animated = True
        Me.BtnManageOrders.BorderRadius = 10
        Me.BtnManageOrders.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.BtnManageOrders.CustomImages.Image = Global.canteen.My.Resources.Resources.icons8_cardboard_box_64
        Me.BtnManageOrders.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BtnManageOrders.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnManageOrders.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnManageOrders.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnManageOrders.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnManageOrders.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.BtnManageOrders.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BtnManageOrders.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.BtnManageOrders.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.BtnManageOrders.HoverState.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BtnManageOrders.HoverState.ForeColor = System.Drawing.Color.White
        Me.BtnManageOrders.Location = New System.Drawing.Point(35, 128)
        Me.BtnManageOrders.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BtnManageOrders.Name = "BtnManageOrders"
        Me.BtnManageOrders.Size = New System.Drawing.Size(171, 35)
        Me.BtnManageOrders.TabIndex = 3
        Me.BtnManageOrders.Text = "Manage Orders"
        Me.BtnManageOrders.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.BtnManageOrders.TextOffset = New System.Drawing.Point(35, 0)
        '
        'btnSignout
        '
        Me.btnSignout.Animated = True
        Me.btnSignout.BorderRadius = 10
        Me.btnSignout.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnSignout.CustomImages.Image = Global.canteen.My.Resources.Resources.icons8_login_66
        Me.btnSignout.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnSignout.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnSignout.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnSignout.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnSignout.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnSignout.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnSignout.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnSignout.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnSignout.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.btnSignout.HoverState.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnSignout.HoverState.ForeColor = System.Drawing.Color.White
        Me.btnSignout.Location = New System.Drawing.Point(35, 429)
        Me.btnSignout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSignout.Name = "btnSignout"
        Me.btnSignout.Size = New System.Drawing.Size(171, 35)
        Me.btnSignout.TabIndex = 2
        Me.btnSignout.Text = "Log Out"
        Me.btnSignout.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnSignout.TextOffset = New System.Drawing.Point(35, 0)
        '
        'lblMenu
        '
        Me.lblMenu.AutoSize = True
        Me.lblMenu.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblMenu.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblMenu.Location = New System.Drawing.Point(35, 105)
        Me.lblMenu.Name = "lblMenu"
        Me.lblMenu.Size = New System.Drawing.Size(78, 15)
        Me.lblMenu.TabIndex = 1
        Me.lblMenu.Text = "STAFF MENU"
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.canteen.My.Resources.Resources.imageedit_3_7131520244
        Me.Guna2PictureBox1.ImageRotate = 0!
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(24, 22)
        Me.Guna2PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(182, 56)
        Me.Guna2PictureBox1.TabIndex = 0
        Me.Guna2PictureBox1.TabStop = False
        '
        'Guna2DragControl1
        '
        Me.Guna2DragControl1.DockIndicatorTransparencyValue = 0.6R
        Me.Guna2DragControl1.TargetControl = Me.Guna2Panel1
        Me.Guna2DragControl1.UseTransparentDrag = True
        '
        'Guna2NotificationPaint1
        '
        Me.Guna2NotificationPaint1.Alignment = Guna.UI2.WinForms.Enums.CustomContentAlignment.MiddleRight
        Me.Guna2NotificationPaint1.BorderThickness = 0
        Me.Guna2NotificationPaint1.FillColor = System.Drawing.Color.Goldenrod
        Me.Guna2NotificationPaint1.Location = New System.Drawing.Point(153, 8)
        Me.Guna2NotificationPaint1.TargetControl = Me.btnNotification
        Me.Guna2NotificationPaint1.Text = "1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label2.Location = New System.Drawing.Point(19, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 28)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Hi, Everyone"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label3.Location = New System.Drawing.Point(19, 42)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(497, 54)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Welcome To The Canteen"
        '
        'PictureBoxOrderNow
        '
        Me.PictureBoxOrderNow.BorderRadius = 18
        Me.PictureBoxOrderNow.Controls.Add(Me.btnOrderFood)
        Me.PictureBoxOrderNow.Controls.Add(Me.Guna2PictureBox2)
        Me.PictureBoxOrderNow.FillColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.PictureBoxOrderNow.Location = New System.Drawing.Point(44, 105)
        Me.PictureBoxOrderNow.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBoxOrderNow.Name = "PictureBoxOrderNow"
        Me.PictureBoxOrderNow.Size = New System.Drawing.Size(790, 170)
        Me.PictureBoxOrderNow.TabIndex = 4
        '
        'btnOrderFood
        '
        Me.btnOrderFood.Animated = True
        Me.btnOrderFood.BackColor = System.Drawing.Color.Transparent
        Me.btnOrderFood.BorderRadius = 40
        Me.btnOrderFood.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnOrderFood.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnOrderFood.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnOrderFood.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnOrderFood.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnOrderFood.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnOrderFood.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnOrderFood.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnOrderFood.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnOrderFood.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnOrderFood.HoverState.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnOrderFood.HoverState.ForeColor = System.Drawing.Color.White
        Me.btnOrderFood.Location = New System.Drawing.Point(461, 34)
        Me.btnOrderFood.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnOrderFood.Name = "btnOrderFood"
        Me.btnOrderFood.Size = New System.Drawing.Size(264, 98)
        Me.btnOrderFood.TabIndex = 3
        Me.btnOrderFood.Text = "Order Food Now"
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Guna2PictureBox2.Image = Global.canteen.My.Resources.Resources.imageedit_12_3041650902
        Me.Guna2PictureBox2.ImageRotate = 0!
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(12, 4)
        Me.Guna2PictureBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(367, 165)
        Me.Guna2PictureBox2.TabIndex = 1
        Me.Guna2PictureBox2.TabStop = False
        '
        'Guna2Panel4
        '
        Me.Guna2Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Guna2Panel4.Controls.Add(Me.PictureBoxDrinks)
        Me.Guna2Panel4.Controls.Add(Me.PictureBoxOrderNow)
        Me.Guna2Panel4.Controls.Add(Me.Label3)
        Me.Guna2Panel4.Controls.Add(Me.Label2)
        Me.Guna2Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2Panel4.Location = New System.Drawing.Point(245, 26)
        Me.Guna2Panel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2Panel4.Name = "Guna2Panel4"
        Me.Guna2Panel4.Size = New System.Drawing.Size(885, 488)
        Me.Guna2Panel4.TabIndex = 5
        '
        'PictureBoxDrinks
        '
        Me.PictureBoxDrinks.BorderRadius = 18
        Me.PictureBoxDrinks.Controls.Add(Me.btnOrderDrinks)
        Me.PictureBoxDrinks.Controls.Add(Me.Guna2PictureBox3)
        Me.PictureBoxDrinks.FillColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.PictureBoxDrinks.Location = New System.Drawing.Point(44, 295)
        Me.PictureBoxDrinks.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBoxDrinks.Name = "PictureBoxDrinks"
        Me.PictureBoxDrinks.Size = New System.Drawing.Size(790, 170)
        Me.PictureBoxDrinks.TabIndex = 5
        '
        'btnOrderDrinks
        '
        Me.btnOrderDrinks.Animated = True
        Me.btnOrderDrinks.BackColor = System.Drawing.Color.Transparent
        Me.btnOrderDrinks.BorderRadius = 40
        Me.btnOrderDrinks.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnOrderDrinks.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.btnOrderDrinks.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.btnOrderDrinks.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.btnOrderDrinks.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.btnOrderDrinks.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.btnOrderDrinks.FillColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.btnOrderDrinks.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnOrderDrinks.ForeColor = System.Drawing.Color.FromArgb(CType(CType(121, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.btnOrderDrinks.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(39, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnOrderDrinks.HoverState.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnOrderDrinks.HoverState.ForeColor = System.Drawing.Color.White
        Me.btnOrderDrinks.Location = New System.Drawing.Point(461, 34)
        Me.btnOrderDrinks.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnOrderDrinks.Name = "btnOrderDrinks"
        Me.btnOrderDrinks.Size = New System.Drawing.Size(264, 98)
        Me.btnOrderDrinks.TabIndex = 3
        Me.btnOrderDrinks.Text = "Order Drinks Here"
        '
        'Guna2PictureBox3
        '
        Me.Guna2PictureBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Guna2PictureBox3.FillColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox3.Image = Global.canteen.My.Resources.Resources.imageedit_14_9677682233
        Me.Guna2PictureBox3.ImageRotate = 0!
        Me.Guna2PictureBox3.Location = New System.Drawing.Point(12, 4)
        Me.Guna2PictureBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox3.Name = "Guna2PictureBox3"
        Me.Guna2PictureBox3.Size = New System.Drawing.Size(367, 165)
        Me.Guna2PictureBox3.TabIndex = 1
        Me.Guna2PictureBox3.TabStop = False
        '
        'TimerToday
        '
        Me.TimerToday.Enabled = True
        '
        'CanteenDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1130, 514)
        Me.Controls.Add(Me.Guna2Panel4)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "CanteenDashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Canteen Management Dashboard"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel2.PerformLayout()
        Me.studentBanner.ResumeLayout(False)
        Me.studentBanner.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PictureBoxOrderNow.ResumeLayout(False)
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel4.ResumeLayout(False)
        Me.Guna2Panel4.PerformLayout()
        Me.PictureBoxDrinks.ResumeLayout(False)
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2ControlBox2 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2ControlBox1 As Guna.UI2.WinForms.Guna2ControlBox
    Friend WithEvents Guna2DragControl1 As Guna.UI2.WinForms.Guna2DragControl
    Friend WithEvents btnSignout As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents lblMenu As Label
    Friend WithEvents btnReportPage As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnManageSales As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnInventory As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BtnManageOrders As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnNotification As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2NotificationPaint1 As Guna.UI2.WinForms.Guna2NotificationPaint
    Friend WithEvents Guna2Panel4 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents PictureBoxDrinks As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnOrderDrinks As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents PictureBoxOrderNow As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnOrderFood As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents studentBanner As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents BannerName As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblTime As Label
    Friend WithEvents TimerToday As Timer
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
End Class
