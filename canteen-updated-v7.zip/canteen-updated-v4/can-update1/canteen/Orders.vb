﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.Form
Public Class Orders

    Dim con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v4\can-update1\canteen\Management1.mdf;Integrated Security=True")
    Private Sub displayItem()
        con.open()
        Dim query = "select * from ItemTable"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        ItemsDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub

    Private Sub CheckCategory()
        con.open()
        Dim query = "select * from ItemTable where ItemCategory='" & comboboxtypes.SelectedValue.ToString() & "'"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        ItemsDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub

    Private Sub fillCategory()
        con.open()
        Dim cmd = New SqlCommand("select * from CategoryTable", con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim table = New DataTable()
        adapter.Fill(table)
        comboboxtypes.DataSource = table
        comboboxtypes.DisplayMember = "CategoryName"
        comboboxtypes.ValueMember = "CategoryName"
        con.close()
    End Sub

    Private Sub Orders_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        displayItem()
        fillCategory()
    End Sub

    Private Sub comboboxtypes_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles comboboxtypes.SelectionChangeCommitted
        CheckCategory()
    End Sub

    Dim productsName As String
    Dim i = 0, price, quantity
    Dim grdTotal = 0

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        If key = 0 Then
            MessageBox.Show("Select A Item")
        ElseIf quantity > stock Then
            MessageBox.Show("Not Enough Stock Available")
        Else
            Dim rownum As Integer = OrderDGV.Rows.Add()
            Dim total = Convert.ToInt32(txtQuantity.Text) * price
            i = i + 1
            OrderDGV.Rows.Item(rownum).Cells("Column1").Value = i
            OrderDGV.Rows.Item(rownum).Cells("Column2").Value = productsName
            OrderDGV.Rows.Item(rownum).Cells("Column3").Value = price
            OrderDGV.Rows.Item(rownum).Cells("Column4").Value = txtQuantity.Text
            OrderDGV.Rows.Item(rownum).Cells("Column5").Value = total
            grdTotal = grdTotal + total
            LabelTotal.Text = "OMR " + Convert.ToString(grdTotal)
            txtQuantity.Text = ""
            key = 0

        End If
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        PrintPreviewDialog1.Show()

    End Sub

    Private Sub addInvoice()
        con.open()
        Dim query = "insert into OrderTable values('" & DateTime.Today.Date.ToString("D") & "','" & grdTotal & "')"
        Dim cmd As SqlCommand
        cmd = New SqlCommand(query, con)
        cmd.ExecuteNonQuery()
        MessageBox.Show("Invoice Added Successfully")
        con.close()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawString("College Canteen", New Font("Times New Roman", 22), Brushes.Teal, 335, 35)
        e.Graphics.DrawString("Invoice", New Font("Times New Roman", 18), Brushes.Teal, 390, 60)
        Dim bm As New Bitmap(Me.OrderDGV.Width, Me.OrderDGV.Height)
        OrderDGV.DrawToBitmap(bm, New Rectangle(0, 0, Me.OrderDGV.Width, Me.OrderDGV.Height))
        e.Graphics.DrawImage(bm, 0, 90)
        e.Graphics.DrawString("Total Amount " + grdTotal.ToString(), New Font("Times New Roman", 15), Brushes.Teal, 320, 580)
        e.Graphics.DrawString("-----***** Thanks For Ordering *****-----", New Font("Times New Roman", 15), Brushes.Teal, 200, 600)

    End Sub

    Private Sub Guna2Button6_Click(sender As Object, e As EventArgs) Handles Guna2Button6.Click
        addInvoice()
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        Dim win = New OrderList
        win.Show()
        Me.Hide()
    End Sub

    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) Handles Guna2ControlBox1.Click
        Me.Close()

    End Sub

    Dim key = 0, stock
    Private Sub ItemsDGV_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles ItemsDGV.CellMouseClick
        Dim row As DataGridViewRow = ItemsDGV.Rows(e.RowIndex)
        productsName = row.Cells(1).Value.ToString

        If productsName = "" Then
            key = 0
            stock = 0
        Else
            key = Convert.ToInt32(row.Cells(0).Value.ToString)
            stock = Convert.ToInt32(row.Cells(4).Value.ToString)
            price = Convert.ToSingle(row.Cells(3).Value.ToString)
        End If
    End Sub
End Class