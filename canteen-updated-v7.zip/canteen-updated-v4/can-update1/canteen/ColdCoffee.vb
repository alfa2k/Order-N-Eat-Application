﻿Public Class ColdCoffee
    Private Sub ButtonQ1Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ1Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceEspresso, TextBoxQ1, CheckBoxEspresso)
    End Sub

    Private Sub ButtonQ1Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ1Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceEspresso, TextBoxQ1, CheckBoxEspresso)
    End Sub

    Private Sub CheckBoxEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxEspresso.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxEspresso, Panel1, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ1, PriceEspresso)
    End Sub



    Private Sub ButtonQ2Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ2Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceMacchiato, TextBoxQ2, CheckBoxMacchiato)
    End Sub

    Private Sub ButtonQ2Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ2Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceMacchiato, TextBoxQ2, CheckBoxMacchiato)
    End Sub

    Private Sub CheckBoxMacchiato_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxMacchiato.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxMacchiato, Panel2, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ2, PriceMacchiato)
    End Sub



    Private Sub ButtonQ3Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ3Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceAmericano, TextBoxQ3, CheckBoxAmericano)
    End Sub

    Private Sub ButtonQ3Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ3Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceAmericano, TextBoxQ3, CheckBoxAmericano)
    End Sub

    Private Sub CheckBoxAmericano_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxAmericano.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxAmericano, Panel3, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ3, PriceAmericano)
    End Sub



    Private Sub ButtonQ4Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ4Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceLatte, TextBoxQ4, CheckBoxLatte)
    End Sub

    Private Sub ButtonQ4Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ4Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceLatte, TextBoxQ4, CheckBoxLatte)
    End Sub

    Private Sub CheckBoxlatte_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxLatte.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxLatte, Panel4, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ4, PriceLatte)
    End Sub



    Private Sub ButtonQ5Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ5Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceCappuccino, TextBoxQ5, CheckBoxCappuccino)
    End Sub

    Private Sub ButtonQ5Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ5Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceCappuccino, TextBoxQ5, CheckBoxCappuccino)
    End Sub

    Private Sub CheckBoxCappuccino_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxCappuccino.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxCappuccino, Panel5, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ5, PriceCappuccino)
    End Sub



    Private Sub ButtonQ6Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ6Inc.Click
        CanteenDashboard.increase(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceMocha, TextBoxQ6, CheckBoxMocha)
    End Sub

    Private Sub ButtonQ6Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ6Dec.Click
        CanteenDashboard.decrease(OrderDrinks.ListBoxItems, OrderDrinks.TextBoxTotal, PriceMocha, TextBoxQ6, CheckBoxMocha)
    End Sub

    Private Sub CheckBoxMocha_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxMocha.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxMocha, Panel6, OrderDrinks.TextBoxTotal, OrderDrinks.ListBoxItems, TextBoxQ6, PriceMocha)
    End Sub



    Private Sub HotCoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CanteenDashboard.QuantityVisibility(TextBoxQ1, Panel1)
        CanteenDashboard.QuantityVisibility(TextBoxQ2, Panel2)
        CanteenDashboard.QuantityVisibility(TextBoxQ3, Panel3)
        CanteenDashboard.QuantityVisibility(TextBoxQ4, Panel4)
        CanteenDashboard.QuantityVisibility(TextBoxQ5, Panel5)
        CanteenDashboard.QuantityVisibility(TextBoxQ6, Panel6)
    End Sub

    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub
End Class