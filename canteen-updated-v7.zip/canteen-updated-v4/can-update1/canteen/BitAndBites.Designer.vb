﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BitAndBites
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBoxQ6 = New System.Windows.Forms.TextBox()
        Me.ButtonQ1Inc = New System.Windows.Forms.Button()
        Me.CheckBoxPotato = New System.Windows.Forms.CheckBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PriceNuggets = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBoxQ3 = New System.Windows.Forms.TextBox()
        Me.ButtonQ3Inc = New System.Windows.Forms.Button()
        Me.ButtonQ3Dec = New System.Windows.Forms.Button()
        Me.PriceWings = New System.Windows.Forms.Label()
        Me.PriceCheeseFries = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ButtonQ4Inc = New System.Windows.Forms.Button()
        Me.ButtonQ4Dec = New System.Windows.Forms.Button()
        Me.CheckBoxWings = New System.Windows.Forms.CheckBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.CheckBoxCheeseFries = New System.Windows.Forms.CheckBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBoxQ2 = New System.Windows.Forms.TextBox()
        Me.ButtonQ2Inc = New System.Windows.Forms.Button()
        Me.ButtonQ2Dec = New System.Windows.Forms.Button()
        Me.CheckBoxLoaded = New System.Windows.Forms.CheckBox()
        Me.TextBoxQ1 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ButtonQ1Dec = New System.Windows.Forms.Button()
        Me.ButtonQ6Inc = New System.Windows.Forms.Button()
        Me.CheckBoxNuggets = New System.Windows.Forms.CheckBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PriceFries = New System.Windows.Forms.Label()
        Me.CheckBoxFries = New System.Windows.Forms.CheckBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBoxQ5 = New System.Windows.Forms.TextBox()
        Me.ButtonQ5Inc = New System.Windows.Forms.Button()
        Me.ButtonQ5Dec = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TextBoxQ4 = New System.Windows.Forms.TextBox()
        Me.PricelLoaded = New System.Windows.Forms.Label()
        Me.PricePotato = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.ButtonQ6Dec = New System.Windows.Forms.Button()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBoxQ6
        '
        Me.TextBoxQ6.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ6.Enabled = False
        Me.TextBoxQ6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ6.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ6.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ6.Name = "TextBoxQ6"
        Me.TextBoxQ6.ReadOnly = True
        Me.TextBoxQ6.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ6.TabIndex = 2
        Me.TextBoxQ6.TabStop = False
        Me.TextBoxQ6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ1Inc
        '
        Me.ButtonQ1Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ1Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ1Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ1Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ1Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ1Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ1Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ1Inc.Name = "ButtonQ1Inc"
        Me.ButtonQ1Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ1Inc.TabIndex = 1
        Me.ButtonQ1Inc.TabStop = False
        Me.ButtonQ1Inc.Text = "+"
        Me.ButtonQ1Inc.UseVisualStyleBackColor = True
        '
        'CheckBoxPotato
        '
        Me.CheckBoxPotato.AutoSize = True
        Me.CheckBoxPotato.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxPotato.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxPotato.ForeColor = System.Drawing.Color.White
        Me.CheckBoxPotato.Location = New System.Drawing.Point(771, 811)
        Me.CheckBoxPotato.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxPotato.Name = "CheckBoxPotato"
        Me.CheckBoxPotato.Size = New System.Drawing.Size(228, 36)
        Me.CheckBoxPotato.TabIndex = 97
        Me.CheckBoxPotato.TabStop = False
        Me.CheckBoxPotato.Text = "Potato Wedges"
        Me.CheckBoxPotato.UseVisualStyleBackColor = True
        '
        'PictureBox6
        '
        Me.PictureBox6.Location = New System.Drawing.Point(795, 595)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 96
        Me.PictureBox6.TabStop = False
        '
        'PriceNuggets
        '
        Me.PriceNuggets.AutoSize = True
        Me.PriceNuggets.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceNuggets.ForeColor = System.Drawing.Color.White
        Me.PriceNuggets.Location = New System.Drawing.Point(479, 859)
        Me.PriceNuggets.Name = "PriceNuggets"
        Me.PriceNuggets.Size = New System.Drawing.Size(139, 38)
        Me.PriceNuggets.TabIndex = 95
        Me.PriceNuggets.Text = "0.75 OMR"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.TextBoxQ3)
        Me.Panel3.Controls.Add(Me.ButtonQ3Inc)
        Me.Panel3.Controls.Add(Me.ButtonQ3Dec)
        Me.Panel3.Location = New System.Drawing.Point(771, 434)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(232, 72)
        Me.Panel3.TabIndex = 86
        '
        'TextBoxQ3
        '
        Me.TextBoxQ3.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ3.Enabled = False
        Me.TextBoxQ3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ3.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ3.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ3.Name = "TextBoxQ3"
        Me.TextBoxQ3.ReadOnly = True
        Me.TextBoxQ3.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ3.TabIndex = 2
        Me.TextBoxQ3.TabStop = False
        Me.TextBoxQ3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ3Inc
        '
        Me.ButtonQ3Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ3Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ3Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ3Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ3Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ3Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ3Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ3Inc.Name = "ButtonQ3Inc"
        Me.ButtonQ3Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ3Inc.TabIndex = 1
        Me.ButtonQ3Inc.TabStop = False
        Me.ButtonQ3Inc.Text = "+"
        Me.ButtonQ3Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ3Dec
        '
        Me.ButtonQ3Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ3Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ3Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ3Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ3Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ3Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ3Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ3Dec.Name = "ButtonQ3Dec"
        Me.ButtonQ3Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ3Dec.TabIndex = 0
        Me.ButtonQ3Dec.TabStop = False
        Me.ButtonQ3Dec.Text = "-"
        Me.ButtonQ3Dec.UseVisualStyleBackColor = True
        '
        'PriceWings
        '
        Me.PriceWings.AutoSize = True
        Me.PriceWings.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceWings.ForeColor = System.Drawing.Color.White
        Me.PriceWings.Location = New System.Drawing.Point(489, 371)
        Me.PriceWings.Name = "PriceWings"
        Me.PriceWings.Size = New System.Drawing.Size(103, 38)
        Me.PriceWings.TabIndex = 83
        Me.PriceWings.Text = "1 OMR"
        '
        'PriceCheeseFries
        '
        Me.PriceCheeseFries.AutoSize = True
        Me.PriceCheeseFries.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceCheeseFries.ForeColor = System.Drawing.Color.White
        Me.PriceCheeseFries.Location = New System.Drawing.Point(127, 371)
        Me.PriceCheeseFries.Name = "PriceCheeseFries"
        Me.PriceCheeseFries.Size = New System.Drawing.Size(124, 38)
        Me.PriceCheeseFries.TabIndex = 79
        Me.PriceCheeseFries.Text = "0.5 OMR"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(109, 107)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 76
        Me.PictureBox1.TabStop = False
        '
        'ButtonQ4Inc
        '
        Me.ButtonQ4Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ4Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ4Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ4Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ4Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ4Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ4Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ4Inc.Name = "ButtonQ4Inc"
        Me.ButtonQ4Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ4Inc.TabIndex = 1
        Me.ButtonQ4Inc.TabStop = False
        Me.ButtonQ4Inc.Text = "+"
        Me.ButtonQ4Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ4Dec
        '
        Me.ButtonQ4Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ4Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ4Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ4Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ4Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ4Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ4Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ4Dec.Name = "ButtonQ4Dec"
        Me.ButtonQ4Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ4Dec.TabIndex = 0
        Me.ButtonQ4Dec.TabStop = False
        Me.ButtonQ4Dec.Text = "-"
        Me.ButtonQ4Dec.UseVisualStyleBackColor = True
        '
        'CheckBoxWings
        '
        Me.CheckBoxWings.AutoSize = True
        Me.CheckBoxWings.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxWings.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxWings.ForeColor = System.Drawing.Color.White
        Me.CheckBoxWings.Location = New System.Drawing.Point(431, 322)
        Me.CheckBoxWings.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxWings.Name = "CheckBoxWings"
        Me.CheckBoxWings.Size = New System.Drawing.Size(223, 36)
        Me.CheckBoxWings.TabIndex = 81
        Me.CheckBoxWings.TabStop = False
        Me.CheckBoxWings.Text = "Chicken Wings"
        Me.CheckBoxWings.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(457, 107)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 80
        Me.PictureBox2.TabStop = False
        '
        'CheckBoxCheeseFries
        '
        Me.CheckBoxCheeseFries.AutoSize = True
        Me.CheckBoxCheeseFries.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxCheeseFries.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxCheeseFries.ForeColor = System.Drawing.Color.White
        Me.CheckBoxCheeseFries.Location = New System.Drawing.Point(99, 322)
        Me.CheckBoxCheeseFries.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxCheeseFries.Name = "CheckBoxCheeseFries"
        Me.CheckBoxCheeseFries.Size = New System.Drawing.Size(202, 36)
        Me.CheckBoxCheeseFries.TabIndex = 77
        Me.CheckBoxCheeseFries.TabStop = False
        Me.CheckBoxCheeseFries.Text = "Cheese Fries"
        Me.CheckBoxCheeseFries.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(795, 107)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 84
        Me.PictureBox3.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TextBoxQ2)
        Me.Panel2.Controls.Add(Me.ButtonQ2Inc)
        Me.Panel2.Controls.Add(Me.ButtonQ2Dec)
        Me.Panel2.Location = New System.Drawing.Point(431, 434)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(232, 72)
        Me.Panel2.TabIndex = 82
        '
        'TextBoxQ2
        '
        Me.TextBoxQ2.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ2.Enabled = False
        Me.TextBoxQ2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ2.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ2.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ2.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ2.Name = "TextBoxQ2"
        Me.TextBoxQ2.ReadOnly = True
        Me.TextBoxQ2.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ2.TabIndex = 2
        Me.TextBoxQ2.TabStop = False
        Me.TextBoxQ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ2Inc
        '
        Me.ButtonQ2Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ2Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ2Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ2Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ2Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ2Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ2Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ2Inc.Name = "ButtonQ2Inc"
        Me.ButtonQ2Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ2Inc.TabIndex = 1
        Me.ButtonQ2Inc.TabStop = False
        Me.ButtonQ2Inc.Text = "+"
        Me.ButtonQ2Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ2Dec
        '
        Me.ButtonQ2Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ2Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ2Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ2Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ2Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ2Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ2Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ2Dec.Name = "ButtonQ2Dec"
        Me.ButtonQ2Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ2Dec.TabIndex = 0
        Me.ButtonQ2Dec.TabStop = False
        Me.ButtonQ2Dec.Text = "-"
        Me.ButtonQ2Dec.UseVisualStyleBackColor = True
        '
        'CheckBoxLoaded
        '
        Me.CheckBoxLoaded.AutoSize = True
        Me.CheckBoxLoaded.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxLoaded.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxLoaded.ForeColor = System.Drawing.Color.White
        Me.CheckBoxLoaded.Location = New System.Drawing.Point(785, 322)
        Me.CheckBoxLoaded.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxLoaded.Name = "CheckBoxLoaded"
        Me.CheckBoxLoaded.Size = New System.Drawing.Size(200, 36)
        Me.CheckBoxLoaded.TabIndex = 85
        Me.CheckBoxLoaded.TabStop = False
        Me.CheckBoxLoaded.Text = "Loaded Fries"
        Me.CheckBoxLoaded.UseVisualStyleBackColor = True
        '
        'TextBoxQ1
        '
        Me.TextBoxQ1.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ1.Enabled = False
        Me.TextBoxQ1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ1.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ1.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ1.Name = "TextBoxQ1"
        Me.TextBoxQ1.ReadOnly = True
        Me.TextBoxQ1.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ1.TabIndex = 2
        Me.TextBoxQ1.TabStop = False
        Me.TextBoxQ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TextBoxQ1)
        Me.Panel1.Controls.Add(Me.ButtonQ1Inc)
        Me.Panel1.Controls.Add(Me.ButtonQ1Dec)
        Me.Panel1.Location = New System.Drawing.Point(83, 434)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(232, 72)
        Me.Panel1.TabIndex = 78
        '
        'ButtonQ1Dec
        '
        Me.ButtonQ1Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ1Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ1Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ1Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ1Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ1Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ1Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ1Dec.Name = "ButtonQ1Dec"
        Me.ButtonQ1Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ1Dec.TabIndex = 0
        Me.ButtonQ1Dec.TabStop = False
        Me.ButtonQ1Dec.Text = "-"
        Me.ButtonQ1Dec.UseVisualStyleBackColor = True
        '
        'ButtonQ6Inc
        '
        Me.ButtonQ6Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ6Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ6Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ6Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ6Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ6Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ6Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ6Inc.Name = "ButtonQ6Inc"
        Me.ButtonQ6Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ6Inc.TabIndex = 1
        Me.ButtonQ6Inc.TabStop = False
        Me.ButtonQ6Inc.Text = "+"
        Me.ButtonQ6Inc.UseVisualStyleBackColor = True
        '
        'CheckBoxNuggets
        '
        Me.CheckBoxNuggets.AutoSize = True
        Me.CheckBoxNuggets.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxNuggets.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxNuggets.ForeColor = System.Drawing.Color.White
        Me.CheckBoxNuggets.Location = New System.Drawing.Point(431, 810)
        Me.CheckBoxNuggets.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxNuggets.Name = "CheckBoxNuggets"
        Me.CheckBoxNuggets.Size = New System.Drawing.Size(250, 36)
        Me.CheckBoxNuggets.TabIndex = 93
        Me.CheckBoxNuggets.TabStop = False
        Me.CheckBoxNuggets.Text = "Chicken Nuggets"
        Me.CheckBoxNuggets.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.Location = New System.Drawing.Point(457, 595)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 92
        Me.PictureBox5.TabStop = False
        '
        'PriceFries
        '
        Me.PriceFries.AutoSize = True
        Me.PriceFries.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PriceFries.ForeColor = System.Drawing.Color.White
        Me.PriceFries.Location = New System.Drawing.Point(127, 859)
        Me.PriceFries.Name = "PriceFries"
        Me.PriceFries.Size = New System.Drawing.Size(139, 38)
        Me.PriceFries.TabIndex = 91
        Me.PriceFries.Text = "0.25 OMR"
        '
        'CheckBoxFries
        '
        Me.CheckBoxFries.AutoSize = True
        Me.CheckBoxFries.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBoxFries.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckBoxFries.ForeColor = System.Drawing.Color.White
        Me.CheckBoxFries.Location = New System.Drawing.Point(143, 811)
        Me.CheckBoxFries.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.CheckBoxFries.Name = "CheckBoxFries"
        Me.CheckBoxFries.Size = New System.Drawing.Size(97, 36)
        Me.CheckBoxFries.TabIndex = 89
        Me.CheckBoxFries.TabStop = False
        Me.CheckBoxFries.Text = "Fries"
        Me.CheckBoxFries.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Location = New System.Drawing.Point(109, 595)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(173, 206)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 88
        Me.PictureBox4.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.TextBoxQ5)
        Me.Panel5.Controls.Add(Me.ButtonQ5Inc)
        Me.Panel5.Controls.Add(Me.ButtonQ5Dec)
        Me.Panel5.Location = New System.Drawing.Point(431, 921)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(232, 72)
        Me.Panel5.TabIndex = 94
        '
        'TextBoxQ5
        '
        Me.TextBoxQ5.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ5.Enabled = False
        Me.TextBoxQ5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ5.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ5.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ5.Name = "TextBoxQ5"
        Me.TextBoxQ5.ReadOnly = True
        Me.TextBoxQ5.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ5.TabIndex = 2
        Me.TextBoxQ5.TabStop = False
        Me.TextBoxQ5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonQ5Inc
        '
        Me.ButtonQ5Inc.Dock = System.Windows.Forms.DockStyle.Right
        Me.ButtonQ5Inc.FlatAppearance.BorderSize = 0
        Me.ButtonQ5Inc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ5Inc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ5Inc.ForeColor = System.Drawing.Color.White
        Me.ButtonQ5Inc.Location = New System.Drawing.Point(170, 0)
        Me.ButtonQ5Inc.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ5Inc.Name = "ButtonQ5Inc"
        Me.ButtonQ5Inc.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ5Inc.TabIndex = 1
        Me.ButtonQ5Inc.TabStop = False
        Me.ButtonQ5Inc.Text = "+"
        Me.ButtonQ5Inc.UseVisualStyleBackColor = True
        '
        'ButtonQ5Dec
        '
        Me.ButtonQ5Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ5Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ5Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ5Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ5Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ5Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ5Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ5Dec.Name = "ButtonQ5Dec"
        Me.ButtonQ5Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ5Dec.TabIndex = 0
        Me.ButtonQ5Dec.TabStop = False
        Me.ButtonQ5Dec.Text = "-"
        Me.ButtonQ5Dec.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.TextBoxQ4)
        Me.Panel4.Controls.Add(Me.ButtonQ4Inc)
        Me.Panel4.Controls.Add(Me.ButtonQ4Dec)
        Me.Panel4.Location = New System.Drawing.Point(83, 921)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(232, 72)
        Me.Panel4.TabIndex = 90
        '
        'TextBoxQ4
        '
        Me.TextBoxQ4.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TextBoxQ4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxQ4.Enabled = False
        Me.TextBoxQ4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxQ4.ForeColor = System.Drawing.Color.White
        Me.TextBoxQ4.Location = New System.Drawing.Point(71, 14)
        Me.TextBoxQ4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxQ4.Name = "TextBoxQ4"
        Me.TextBoxQ4.ReadOnly = True
        Me.TextBoxQ4.Size = New System.Drawing.Size(90, 32)
        Me.TextBoxQ4.TabIndex = 2
        Me.TextBoxQ4.TabStop = False
        Me.TextBoxQ4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PricelLoaded
        '
        Me.PricelLoaded.AutoSize = True
        Me.PricelLoaded.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PricelLoaded.ForeColor = System.Drawing.Color.White
        Me.PricelLoaded.Location = New System.Drawing.Point(812, 371)
        Me.PricelLoaded.Name = "PricelLoaded"
        Me.PricelLoaded.Size = New System.Drawing.Size(139, 38)
        Me.PricelLoaded.TabIndex = 87
        Me.PricelLoaded.Text = "0.75 OMR"
        '
        'PricePotato
        '
        Me.PricePotato.AutoSize = True
        Me.PricePotato.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PricePotato.ForeColor = System.Drawing.Color.White
        Me.PricePotato.Location = New System.Drawing.Point(812, 859)
        Me.PricePotato.Name = "PricePotato"
        Me.PricePotato.Size = New System.Drawing.Size(124, 38)
        Me.PricePotato.TabIndex = 99
        Me.PricePotato.Text = "0.5 OMR"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.TextBoxQ6)
        Me.Panel6.Controls.Add(Me.ButtonQ6Inc)
        Me.Panel6.Controls.Add(Me.ButtonQ6Dec)
        Me.Panel6.Location = New System.Drawing.Point(771, 921)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(232, 72)
        Me.Panel6.TabIndex = 98
        '
        'ButtonQ6Dec
        '
        Me.ButtonQ6Dec.Dock = System.Windows.Forms.DockStyle.Left
        Me.ButtonQ6Dec.FlatAppearance.BorderSize = 0
        Me.ButtonQ6Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonQ6Dec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonQ6Dec.ForeColor = System.Drawing.Color.White
        Me.ButtonQ6Dec.Location = New System.Drawing.Point(0, 0)
        Me.ButtonQ6Dec.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonQ6Dec.Name = "ButtonQ6Dec"
        Me.ButtonQ6Dec.Size = New System.Drawing.Size(62, 72)
        Me.ButtonQ6Dec.TabIndex = 0
        Me.ButtonQ6Dec.TabStop = False
        Me.ButtonQ6Dec.Text = "-"
        Me.ButtonQ6Dec.UseVisualStyleBackColor = True
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'BitAndBites
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1086, 1101)
        Me.Controls.Add(Me.CheckBoxPotato)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PriceNuggets)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.PriceWings)
        Me.Controls.Add(Me.PriceCheeseFries)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CheckBoxWings)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.CheckBoxCheeseFries)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.CheckBoxLoaded)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CheckBoxNuggets)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PriceFries)
        Me.Controls.Add(Me.CheckBoxFries)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.PricelLoaded)
        Me.Controls.Add(Me.PricePotato)
        Me.Controls.Add(Me.Panel6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.Name = "BitAndBites"
        Me.Text = "BitAndBites"
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxQ6 As TextBox
    Friend WithEvents ButtonQ1Inc As Button
    Friend WithEvents CheckBoxPotato As CheckBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PriceNuggets As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBoxQ3 As TextBox
    Friend WithEvents ButtonQ3Inc As Button
    Friend WithEvents ButtonQ3Dec As Button
    Friend WithEvents PriceWings As Label
    Friend WithEvents PriceCheeseFries As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ButtonQ4Inc As Button
    Friend WithEvents ButtonQ4Dec As Button
    Friend WithEvents CheckBoxWings As CheckBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents CheckBoxCheeseFries As CheckBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBoxQ2 As TextBox
    Friend WithEvents ButtonQ2Inc As Button
    Friend WithEvents ButtonQ2Dec As Button
    Friend WithEvents CheckBoxLoaded As CheckBox
    Friend WithEvents TextBoxQ1 As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ButtonQ1Dec As Button
    Friend WithEvents ButtonQ6Inc As Button
    Friend WithEvents CheckBoxNuggets As CheckBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PriceFries As Label
    Friend WithEvents CheckBoxFries As CheckBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBoxQ5 As TextBox
    Friend WithEvents ButtonQ5Inc As Button
    Friend WithEvents ButtonQ5Dec As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBoxQ4 As TextBox
    Friend WithEvents PricelLoaded As Label
    Friend WithEvents PricePotato As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents ButtonQ6Dec As Button
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
End Class
