﻿Public Class LoadUpForm
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        LoadingBar.Increment(2.5)
        If LoadingBar.Value = 100 Then
            Me.Hide()
            Dim log = New LoginPage
            log.Show()
            Timer1.Enabled = False

        End If
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()

    End Sub
End Class