﻿Public Class Salads
    Private Sub ButtonQ1Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ1Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCaesar, TextBoxQ1, CheckBoxCaesar)
    End Sub

    Private Sub ButtonQ1Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ1Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCaesar, TextBoxQ1, CheckBoxCaesar)
    End Sub

    Private Sub CheckBoxEspresso_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxCaesar.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxCaesar, Panel1, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ1, PriceCaesar)
    End Sub



    Private Sub ButtonQ2Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ2Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceGreek, TextBoxQ2, CheckBoxMacchiato)
    End Sub

    Private Sub ButtonQ2Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ2Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceGreek, TextBoxQ2, CheckBoxMacchiato)
    End Sub

    Private Sub CheckBoxMacchiato_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxMacchiato.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxMacchiato, Panel2, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ2, PriceGreek)
    End Sub



    Private Sub ButtonQ3Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ3Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceAmericano, TextBoxQ3, CheckBoxAmericano)
    End Sub

    Private Sub ButtonQ3Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ3Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceAmericano, TextBoxQ3, CheckBoxAmericano)
    End Sub

    Private Sub CheckBoxAmericano_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxAmericano.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxAmericano, Panel3, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ3, PriceAmericano)
    End Sub



    Private Sub ButtonQ4Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ4Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCrab, TextBoxQ4, CheckBoxCrab)
    End Sub

    Private Sub ButtonQ4Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ4Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceCrab, TextBoxQ4, CheckBoxCrab)
    End Sub

    Private Sub CheckBoxlatte_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxCrab.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxCrab, Panel4, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ4, PriceCrab)
    End Sub



    Private Sub ButtonQ5Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ5Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceAsian, TextBoxQ5, CheckBoxAsian)
    End Sub

    Private Sub ButtonQ5Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ5Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceAsian, TextBoxQ5, CheckBoxAsian)
    End Sub

    Private Sub CheckBoxCappuccino_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxAsian.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxAsian, Panel5, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ5, PriceAsian)
    End Sub



    Private Sub ButtonQ6Inc_Click(sender As Object, e As EventArgs) Handles ButtonQ6Inc.Click
        CanteenDashboard.increase(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceVeggie, TextBoxQ6, CheckBoxMocha)
    End Sub

    Private Sub ButtonQ6Dec_Click(sender As Object, e As EventArgs) Handles ButtonQ6Dec.Click
        CanteenDashboard.decrease(OrderFood.ListBoxItems, OrderFood.TextBoxTotal, PriceVeggie, TextBoxQ6, CheckBoxMocha)
    End Sub

    Private Sub CheckBoxMocha_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxMocha.CheckedChanged
        CanteenDashboard.checkingAnItem(CheckBoxMocha, Panel6, OrderFood.TextBoxTotal, OrderFood.ListBoxItems, TextBoxQ6, PriceVeggie)
    End Sub



    Private Sub HotCoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CanteenDashboard.QuantityVisibility(TextBoxQ1, Panel1)
        CanteenDashboard.QuantityVisibility(TextBoxQ2, Panel2)
        CanteenDashboard.QuantityVisibility(TextBoxQ3, Panel3)
        CanteenDashboard.QuantityVisibility(TextBoxQ4, Panel4)
        CanteenDashboard.QuantityVisibility(TextBoxQ5, Panel5)
        CanteenDashboard.QuantityVisibility(TextBoxQ6, Panel6)
    End Sub



    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) 
        Me.Close()
    End Sub
End Class