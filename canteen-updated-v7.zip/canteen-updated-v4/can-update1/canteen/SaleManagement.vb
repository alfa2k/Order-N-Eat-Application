﻿Imports System.Data.SqlClient
Public Class SaleManagement
    Dim con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v4\can-update1\canteen\Management1.mdf;Integrated Security=True")
    Private Sub fillSaleID()
        con.open()
        Dim cmd = New SqlCommand("select * from SalesTable", con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim table = New DataTable()
        adapter.Fill(table)
        cbxsales.DataSource = table
        cbxsales.DisplayMember = "Id"
        cbxsales.ValueMember = "Id"
        con.close()
    End Sub
    Private Sub fillSaleTotal()
        con.open()
        Dim cmd = New SqlCommand("select sum(sale) from SalesTable", con)
        Dim sum As Double = cmd.ExecuteScalar()
        txttotal.Text = sum
        con.close()
    End Sub
    Private Sub displaySales()
        con.open()
        Dim query = "select * from SalesTable"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        SalesDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub
    Private Sub SaleManagement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtdatesales.Text = Date.Today
        displaySales()
        fillSaleID()
        fillSaleTotal()
    End Sub
    Private Sub btnsaleadd_Click(sender As Object, e As EventArgs) Handles btnsaleadd.Click
        If Not IsNumeric(txtsale.Text) Then
            MessageBox.Show("Invalid Sale input.")
        Else
            con.open()
            Dim query = "insert into SalesTable values('" & txtnamesales.Text & "','" & DateTime.Today & "'," & txtsale.Text & ")"
            Dim cmd = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            con.close()
            displaySales()
            fillSaleID()
            fillSaleTotal()
        End If
    End Sub

    Private Sub btnsaleremove_Click(sender As Object, e As EventArgs) Handles btnsaleremove.Click
        con.open()
        Dim query = "delete from SalesTable where Id = '" & cbxsales.SelectedValue & "'"
        Dim cmd = New SqlCommand(query, con)
        cmd.ExecuteNonQuery()
        con.close()
        displaySales()
        fillSaleID()
        fillSaleTotal()
    End Sub
End Class