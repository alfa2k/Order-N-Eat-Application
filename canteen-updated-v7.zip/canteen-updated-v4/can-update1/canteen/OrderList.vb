﻿Imports System.Data.SqlClient
Public Class OrderList
    Dim con = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\smart\OneDrive\Documents\NU\canteen\Management1.mdf;Integrated Security=True")
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        Orders.Show()
        Me.Hide()
    End Sub

    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) Handles Guna2ControlBox1.Click
        Me.Close()
        Orders.Show()
    End Sub

    Private Sub displayOrders()
        con.open()
        Dim query = "select * from OrderTable"
        Dim cmd = New SqlCommand(query, con)
        Dim adapter = New SqlDataAdapter(cmd)
        Dim builder = New SqlCommandBuilder(adapter)
        Dim ds = New DataSet()
        adapter.Fill(ds)
        OrderListDGV.DataSource = ds.Tables(0)
        con.close()
    End Sub

    Private Sub OrderList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        displayOrders()
    End Sub
End Class