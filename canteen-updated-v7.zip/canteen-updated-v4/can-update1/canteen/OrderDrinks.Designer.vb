﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class OrderDrinks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OrderDrinks))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnClose = New Guna.UI2.WinForms.Guna2Button()
        Me.ButtonJuice = New System.Windows.Forms.Button()
        Me.ButtonSoda = New System.Windows.Forms.Button()
        Me.ButtonColdCoffee = New System.Windows.Forms.Button()
        Me.ButtonHotCoffee = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PanelChildForm = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ListBoxItems = New System.Windows.Forms.ListBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBoxTotal = New System.Windows.Forms.TextBox()
        Me.LabelTotal = New System.Windows.Forms.Label()
        Me.ButtonCheckout = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.LabelYourCart = New System.Windows.Forms.Label()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.Guna2Elipse1 = New Guna.UI2.WinForms.Guna2Elipse(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel1.Controls.Add(Me.BtnClose)
        Me.Panel1.Controls.Add(Me.ButtonJuice)
        Me.Panel1.Controls.Add(Me.ButtonSoda)
        Me.Panel1.Controls.Add(Me.ButtonColdCoffee)
        Me.Panel1.Controls.Add(Me.ButtonHotCoffee)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(299, 1099)
        Me.Panel1.TabIndex = 0
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.BtnClose.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.BtnClose.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.BtnClose.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.BtnClose.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnClose.FillColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.BtnClose.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BtnClose.ForeColor = System.Drawing.Color.White
        Me.BtnClose.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(96, Byte), Integer))
        Me.BtnClose.Location = New System.Drawing.Point(0, 638)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(299, 64)
        Me.BtnClose.TabIndex = 12
        Me.BtnClose.Text = "Return Back"
        '
        'ButtonJuice
        '
        Me.ButtonJuice.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonJuice.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonJuice.FlatAppearance.BorderSize = 0
        Me.ButtonJuice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.ButtonJuice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonJuice.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonJuice.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonJuice.Location = New System.Drawing.Point(0, 518)
        Me.ButtonJuice.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonJuice.Name = "ButtonJuice"
        Me.ButtonJuice.Size = New System.Drawing.Size(299, 120)
        Me.ButtonJuice.TabIndex = 3
        Me.ButtonJuice.Text = "Juice"
        Me.ButtonJuice.UseVisualStyleBackColor = False
        '
        'ButtonSoda
        '
        Me.ButtonSoda.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonSoda.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonSoda.FlatAppearance.BorderSize = 0
        Me.ButtonSoda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.ButtonSoda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonSoda.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonSoda.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonSoda.Location = New System.Drawing.Point(0, 398)
        Me.ButtonSoda.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonSoda.Name = "ButtonSoda"
        Me.ButtonSoda.Size = New System.Drawing.Size(299, 120)
        Me.ButtonSoda.TabIndex = 2
        Me.ButtonSoda.Text = "Soda"
        Me.ButtonSoda.UseVisualStyleBackColor = False
        '
        'ButtonColdCoffee
        '
        Me.ButtonColdCoffee.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonColdCoffee.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonColdCoffee.FlatAppearance.BorderSize = 0
        Me.ButtonColdCoffee.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.ButtonColdCoffee.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonColdCoffee.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonColdCoffee.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonColdCoffee.Location = New System.Drawing.Point(0, 278)
        Me.ButtonColdCoffee.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonColdCoffee.Name = "ButtonColdCoffee"
        Me.ButtonColdCoffee.Size = New System.Drawing.Size(299, 120)
        Me.ButtonColdCoffee.TabIndex = 1
        Me.ButtonColdCoffee.Text = "Cold Coffee"
        Me.ButtonColdCoffee.UseVisualStyleBackColor = False
        '
        'ButtonHotCoffee
        '
        Me.ButtonHotCoffee.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonHotCoffee.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonHotCoffee.FlatAppearance.BorderSize = 0
        Me.ButtonHotCoffee.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.ButtonHotCoffee.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonHotCoffee.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonHotCoffee.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonHotCoffee.Location = New System.Drawing.Point(0, 158)
        Me.ButtonHotCoffee.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonHotCoffee.Name = "ButtonHotCoffee"
        Me.ButtonHotCoffee.Size = New System.Drawing.Size(299, 120)
        Me.ButtonHotCoffee.TabIndex = 0
        Me.ButtonHotCoffee.Text = "Hot Coffee"
        Me.ButtonHotCoffee.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Image = Global.canteen.My.Resources.Resources.imageedit_14_9677682233
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(299, 158)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PanelChildForm
        '
        Me.PanelChildForm.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.PanelChildForm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelChildForm.Location = New System.Drawing.Point(299, 0)
        Me.PanelChildForm.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.PanelChildForm.Name = "PanelChildForm"
        Me.PanelChildForm.Size = New System.Drawing.Size(1123, 1099)
        Me.PanelChildForm.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel3.Controls.Add(Me.ListBoxItems)
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Controls.Add(Me.ButtonCheckout)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(1422, 0)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(412, 1099)
        Me.Panel3.TabIndex = 0
        '
        'ListBoxItems
        '
        Me.ListBoxItems.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ListBoxItems.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBoxItems.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBoxItems.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ListBoxItems.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ListBoxItems.FormattingEnabled = True
        Me.ListBoxItems.ItemHeight = 30
        Me.ListBoxItems.Items.AddRange(New Object() {" "})
        Me.ListBoxItems.Location = New System.Drawing.Point(0, 143)
        Me.ListBoxItems.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ListBoxItems.Name = "ListBoxItems"
        Me.ListBoxItems.Size = New System.Drawing.Size(412, 706)
        Me.ListBoxItems.TabIndex = 0
        Me.ListBoxItems.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Panel5.Controls.Add(Me.TextBoxTotal)
        Me.Panel5.Controls.Add(Me.LabelTotal)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(0, 849)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(412, 140)
        Me.Panel5.TabIndex = 3
        '
        'TextBoxTotal
        '
        Me.TextBoxTotal.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.TextBoxTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.TextBoxTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxTotal.Enabled = False
        Me.TextBoxTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.TextBoxTotal.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBoxTotal.Location = New System.Drawing.Point(243, 53)
        Me.TextBoxTotal.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.TextBoxTotal.Name = "TextBoxTotal"
        Me.TextBoxTotal.ReadOnly = True
        Me.TextBoxTotal.Size = New System.Drawing.Size(151, 26)
        Me.TextBoxTotal.TabIndex = 4
        '
        'LabelTotal
        '
        Me.LabelTotal.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.LabelTotal.AutoSize = True
        Me.LabelTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LabelTotal.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.LabelTotal.Location = New System.Drawing.Point(19, 53)
        Me.LabelTotal.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.LabelTotal.Name = "LabelTotal"
        Me.LabelTotal.Size = New System.Drawing.Size(73, 29)
        Me.LabelTotal.TabIndex = 3
        Me.LabelTotal.Text = "Total"
        '
        'ButtonCheckout
        '
        Me.ButtonCheckout.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.ButtonCheckout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ButtonCheckout.FlatAppearance.BorderSize = 0
        Me.ButtonCheckout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonCheckout.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ButtonCheckout.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ButtonCheckout.Location = New System.Drawing.Point(0, 989)
        Me.ButtonCheckout.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.ButtonCheckout.Name = "ButtonCheckout"
        Me.ButtonCheckout.Size = New System.Drawing.Size(412, 110)
        Me.ButtonCheckout.TabIndex = 2
        Me.ButtonCheckout.Text = "Proceed to checkout"
        Me.ButtonCheckout.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(69, Byte), Integer), CType(CType(82, Byte), Integer))
        Me.Panel4.Controls.Add(Me.LabelYourCart)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(412, 143)
        Me.Panel4.TabIndex = 1
        '
        'LabelYourCart
        '
        Me.LabelYourCart.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LabelYourCart.AutoSize = True
        Me.LabelYourCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LabelYourCart.ForeColor = System.Drawing.SystemColors.Control
        Me.LabelYourCart.Location = New System.Drawing.Point(134, 52)
        Me.LabelYourCart.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.LabelYourCart.Name = "LabelYourCart"
        Me.LabelYourCart.Size = New System.Drawing.Size(134, 32)
        Me.LabelYourCart.TabIndex = 0
        Me.LabelYourCart.Text = "Your Cart"
        '
        'Guna2Elipse1
        '
        Me.Guna2Elipse1.TargetControl = Me
        '
        'OrderDrinks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1834, 1099)
        Me.Controls.Add(Me.PanelChildForm)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.MinimumSize = New System.Drawing.Size(1137, 749)
        Me.Name = "OrderDrinks"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Order Drinks"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents ButtonJuice As Button
    Friend WithEvents ButtonSoda As Button
    Friend WithEvents ButtonColdCoffee As Button
    Friend WithEvents ButtonHotCoffee As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PanelChildForm As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBoxTotal As TextBox
    Friend WithEvents LabelTotal As Label
    Friend WithEvents ButtonCheckout As Button
    Friend WithEvents ListBoxItems As ListBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents LabelYourCart As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents Guna2Elipse1 As Guna.UI2.WinForms.Guna2Elipse
    Friend WithEvents BtnClose As Guna.UI2.WinForms.Guna2Button
End Class
