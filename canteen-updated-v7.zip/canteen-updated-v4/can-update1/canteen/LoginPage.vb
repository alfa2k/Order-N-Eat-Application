﻿Imports System.Data
Imports System.Data.SqlClient
Module getName
    Private strName As String
    Public Property getSName() As String
        Get
            Return strName
        End Get
        Set(ByVal sName As String)
            strName = sName
        End Set
    End Property
End Module
Public Class LoginPage
    Public checkLogin As Boolean = False

    Private Sub LoginSubmitButton_Click(sender As Object, e As EventArgs) Handles LoginSubmitButton.Click

        If RadioButtonStaff.Checked = True Then

            If TextBoxUserName.Text = "" Or TextBoxPassword.Text = "" Then
                MessageBox.Show("Enter Username and Password")
                checkLogin = False
            Else

                Dim con As SqlConnection = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v4\can-update1\canteen\StaffLogin.mdf;Integrated Security=True")
                Dim cmd As SqlCommand = New SqlCommand("select * from StaffLogin where UserID = '" + TextBoxUserName.Text + "' and Password = '" + TextBoxPassword.Text + "'", con)
                Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                Dim dt As DataTable = New DataTable()
                sda.Fill(dt)

                If (dt.Rows.Count > 0) Then
                    MessageBox.Show("Successfull Login")
                    Dim page = New CanteenDashboard
                    checkLogin = True
                    page.Show()
                    Me.Hide()
                Else
                    MessageBox.Show("Incorrect Username or Password" & vbCrLf & "If You Are New Staff Please Create An Account")
                    TextBoxUserName.Text = ""
                    TextBoxPassword.Text = ""
                    checkLogin = False
                End If

            End If

        ElseIf RadioButtonStudent.Checked = True Then

            CanteenDashboard.BtnManageOrders.Visible = False
            CanteenDashboard.btnInventory.Visible = False


            If TextBoxUserName.Text = "" Or TextBoxPassword.Text = "" Then
                MessageBox.Show("Enter Username and Password")
                checkLogin = False
            Else

                Dim con As SqlConnection = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v4\can-update1\canteen\StudentsLogin.mdf;Integrated Security=True")
                Dim cmd As SqlCommand = New SqlCommand("select * from StudentLogin where Username = '" + TextBoxUserName.Text + "' and Password = '" + TextBoxPassword.Text + "'", con)
                Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                Dim dt As DataTable = New DataTable()
                sda.Fill(dt)

                If (dt.Rows.Count > 0) Then
                    MessageBox.Show("Successfull Login")

                    Dim page = New CanteenDashboard
                    page.studentBanner.Visible = True
                    page.Label2.Text = "Hi There"
                    page.BannerName.Text = "Welcome,"
                    page.Label4.Text = TextBoxUserName.Text
                    page.lblMenu.Visible = False
                    page.btnInventory.Visible = False
                    page.btnManageSales.Visible = False
                    page.btnNotification.Visible = False
                    page.btnReportPage.Visible = False
                    page.BtnManageOrders.Visible = False
                    checkLogin = True
                    page.Show()
                    Me.Hide()
                Else
                    MessageBox.Show("Incorrect Username or Password" & vbCrLf & "If You Are A New Sudent Please Create An Account")
                    TextBoxUserName.Text = ""
                    TextBoxPassword.Text = ""
                    checkLogin = False
                End If

            End If
        Else
            MessageBox.Show("Please Select the Choice - Are you a Student or Staff")
        End If

        If checkLogin = False Then
            btnCreateAccount.Visible = True
        End If
    End Sub

    Private Sub btnCreateAccount_Click(sender As Object, e As EventArgs) Handles btnCreateAccount.Click

        LoginSubmitButton.Visible = False
        LabelUsername.Text = "Enter New Username: "
        LabelPassword.Text = "Enter New Password: "

        If RadioButtonStaff.Checked = True Then

            If TextBoxUserName.Text = "" Or TextBoxPassword.Text = "" Then
                MessageBox.Show("Please Enter the New Username and Password")
                checkLogin = False
            Else

                Dim con As SqlConnection = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v3\can-update1\canteen\StaffLogin.mdf;Integrated Security=True")
                con.Open()
                Dim cmd As SqlCommand = New SqlCommand("insert into StaffLogin values('" & TextBoxUserName.Text & "','" & TextBoxPassword.Text & "')", con)
                cmd.ExecuteNonQuery()
                con.Close()
                MessageBox.Show("Account Successfully Created")
                LoginSubmitButton.Visible = True
            End If

        ElseIf RadioButtonStudent.Checked = True Then

            If TextBoxUserName.Text = "" Or TextBoxPassword.Text = "" Then
                MessageBox.Show("Please Enter New Username and Password")
                checkLogin = False
            Else

                Dim con As SqlConnection = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\albus\source\repos\canteen-updated-v3\can-update1\canteen\StudentsLogin.mdf;Integrated Security=True")
                con.Open()
                Dim cmd As SqlCommand = New SqlCommand("insert into StudentLogin values('" & TextBoxUserName.Text & "','" & TextBoxPassword.Text & "')", con)
                cmd.ExecuteNonQuery()
                con.Close()
                MessageBox.Show("Account Successfully Created")
                LoginSubmitButton.Visible = True
            End If
        Else
            MessageBox.Show("Please Select the Choice - Are you a Student or Staff")
        End If

    End Sub

    Private Sub Guna2ControlBox1_Click(sender As Object, e As EventArgs) Handles Guna2ControlBox1.Click
        Application.Exit()
    End Sub

    Private Sub TextBoxUserName_TextChanged(sender As Object, e As EventArgs) Handles TextBoxUserName.TextChanged
        getSName = TextBoxUserName.Text
    End Sub
End Class