﻿Public Class OrderFood
    Private currentForm As Form = Nothing
    Private Sub openChildForm(childForm As Form) 'sub for Docking the childForm(s)/Forms in place of PanelChildForm
        If currentForm Is childForm AndAlso childForm.Visible = True Then 'if the same child form is called through a button, make all forms invisible (like close)
            Breakfast.Visible = False
            Salads.Visible = False
            BitAndBites.Visible = False
            Soups.Visible = False
            FoodCheckout.Visible = False
        Else 'if not, put the form that is called through a button in PanelChildForm
            currentForm = childForm
            childForm.TopLevel = False
            childForm.FormBorderStyle = FormBorderStyle.None
            childForm.Dock = DockStyle.Fill
            PanelChildForm.Controls.Add(childForm)
            PanelChildForm.Tag = childForm
            childForm.BringToFront()
            childForm.Show()
        End If
    End Sub

    Private Sub changeButtonColor(button As Button) 'sub for changing the color of button when pressed
        If button.BackColor = Color.FromArgb(25, 28, 37) Then 'if the button that is pressed was the last button pressed beforehand, change it back to the normal color
            button.BackColor = Color.FromArgb(35, 38, 47)
        Else 'if not, change all colors to normal then make the pressed button light gray
            ButtonBreakfast.BackColor = Color.FromArgb(35, 38, 47)
            ButtonSalads.BackColor = Color.FromArgb(35, 38, 47)
            ButtonBits.BackColor = Color.FromArgb(35, 38, 47)
            ButtonSoups.BackColor = Color.FromArgb(35, 38, 47)
            ButtonCheckout.BackColor = Color.FromArgb(35, 38, 47)
            button.BackColor = Color.FromArgb(25, 28, 37)
        End If
    End Sub

    Private Sub ButtonChicken_Click(sender As Object, e As EventArgs) Handles ButtonBreakfast.Click
        openChildForm(Breakfast) 'calling openChildForm sub for FormChicken when ButtonChicken is pressed to insert the form FormChicken in the place of PanelChildForm
        changeButtonColor(ButtonBreakfast) 'calling openChildForm sub for FormChicken when ButtonChicken is pressed
    End Sub

    Private Sub ButtonMcsaver_Click(sender As Object, e As EventArgs) Handles ButtonSalads.Click
        openChildForm(Salads)
        changeButtonColor(ButtonSalads)
    End Sub

    Private Sub ButtonDesserts_Click(sender As Object, e As EventArgs) Handles ButtonBits.Click
        openChildForm(BitAndBites)
        changeButtonColor(ButtonBits)
    End Sub

    Private Sub ButtonCold_Click(sender As Object, e As EventArgs) Handles ButtonSoups.Click
        openChildForm(Soups)
        changeButtonColor(ButtonSoups)
    End Sub

    Private Sub FormMcDonalds_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBoxTotal.Text = "0 OMR" 'default value of TextBoxTotal
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles ButtonCheckout.Click
        If TextBoxTotal.Text = "0 OMR" Then 'if TextBoxTotal is empty
            MessageBox.Show("Your Cart Is Empty", "Empty Cart") 'print message that the cart is empty
        Else 'if not
            openChildForm(FoodCheckout) 'open FormCheckout in place of PanelChildForm
            changeButtonColor(ButtonCheckout)
        End If
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub
End Class